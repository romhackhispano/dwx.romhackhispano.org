--------------------------------------------
 X816 
 Readme en espa�ol por Dark-N al 30% 
 naldo_go@hotmail.com
 http://www.nekein.com/tyh
 29-10-2004
--------------------------------------------

Introduction
------------
X816 es un ensamblador(assembler) que genera codigo de maquina pra la SNES, o
mas especificamante para la 65816.  X816 se basa 
en el assembler visto sobre C64/128 pero con unas pocas adiciones
para darle velocidad a la SNES.

X816 soporta el set completo de instrucciones de la 65816 y todos su modos
de direccionamiento.  Tambien, un set de Directivas de ensamblador son
incluidas para hacer que el trabajo de los programadores un poco mas facil.
X816 toma cualquier codigo fuente guradado en una archivo de texto 
standard y genera un codigo binario.


Advertencia
-----------------
X816 es un software de dominio publico.  Lo que hagas con esto es asunto
tuyo. El autor de no responsabiliza por los da�os que con X816 puedas causar.
Es libre enviar este archivo por internet, o  tus amigos.


Corriendo X816
----------------------
Para ensamblar tu codigo fuente solo escribe X816 seguido por el nombre de 
archivo fuente, luego <Enter>.  Hay unas pocas opciones que pueden ser
activadas en la linea de comandos antes de ensamblar.  
Ahora sigue un sumario de como ensamblar un codigo fuente que estan disponibles:

   usar: X816 [-opcion] <fuente[.asm|.src|.s]>
   opcion:
    $: genera archivo simbolo
    d: muestra ensamblado
    l: (letra ele) genera lista
    s: hace un archivo SMC

Estas opciones estan inicialmente desactivadas. Para incluirlas, solo incluye la letra
correspondiente en la linea de comandos, con una guion (-) antes.
Mas opciones pueden ser activadas si usas las Diretivas de asembler.

Ejemplo de compilacion: 
   c:\snes\x816_asm> X816.EXE -s archi.asm

Aqui ensamblamos el fuente: archi.asm y la salida sera un archivo SNES llamadao archi.smc 
y un archivo binario llamado archi.bin.

Una vez dado el codigo fuente y las opciones que se deseen, X816 comenzara a ensamblar el
codigo fuente en 3 pasos. EL primer paso y segundo salvan la
de valores o simbolos. El 3er es cuando el archivo binario es escrito. Si se encuentran
errores los mostrara en el paso final.


Formateo de Codigo Fuente
----------------------------------------
Antes que cualquier codigo sea generado, el codido fuente debe tener una DIRECCION de origen 
Si cualquier codigo es puesto antes de la direccion de origen, el compilador tirar� un error fatal.

Tu codigo fuente debera ser un texto en estandar ASCII. La mayoria de la gente usa una sola 
instruccion por linea.. Esto hace leer mas facil el codigo. En todo caso, X816 te da la opcion de usar un 
doble punto (:) o un backslash (\) para separar multiples instrucciones en una linea. DE todas maneras
hay ciertas restricciones para usar multiples instrucciones en una misma linea.

X816 ve una linea de codigo en 4 secciones: Label, Operador, Operando, Comentarios

   Label      Operador      Operando     Comentarios
--------------------------------------------------------------------------
   start          lda            #32               ; carga 32 dentro de A
                   dcb            32,45,67        ; valores de datos
                   iny
                   inc           $1000

No todos las seciones necesariamente se usan.  Cualquier texto despues del comentario
(comentarios con ; ) es ignorado, asi que no pongas mas instruciones despues de un
comentario. Aqui un ejemplo de multiples instruucciones en un sola linea:

   lda $1000 : cmp #$16 : bne forward ; Esto chequea la direccion $1000 con el valor #$16, si es asi, salta

Los espacios deben estar antes y despues de los 2 puntos ( : ).  Tambien puedes usar \ para separar.


Archivos de salida.
---------------------------
Solo un archivo BINARIO es escrito cuando se corre SIN OPCIONES. Los otros archivos de salida
que se pueden obtener son: .LST (lista de ensamblado o Trace) o 
.SYM (tabla de simbolos) o .SMC (ejecutable de Super Famicon):

   BIN   - archivo binario
   LST   - lista de ensamblado (assembly listing)
   SYM   - symbol table listing (tabla de simbolos)
   SMC   - Super Magicom executable file (archivo de snes .smc)

Un archivo temporal puede ser escrito en el disco cuando la Tabla de simbolos
es generada mas rapido que en memoria.

El archivo binario es el actual producto del proceso de ensamblado.

El archivo con la Lista de ensamblado (assembly listing file) es la actual salida
de el proceso de ensamblado. Se puede ver con un editor de texto sencillo (recomiendo EditPad).
Esta muestra los simbolos hex que representan cada instrucion
ademas de hacer una TRAZA de lo que se ensamblo (parecido al de snes9X). 
Tambien, muestra el numero de lineas, bytes de codigo y lineas del fuente dividida en 4 secciones. 
La lista tiene el siguiente formato.

      1                 2               3                 4                 5                  6                7
num. linea   Direccion     Bytes#1-4    Simbolo      Operador      Operando   Comentarios

   1. Numero de Linea de codigo. Lineas blancas igual son cosideradas sentencias.
   2. Actual direcci�n de Linea.  Esta aumenta segun el numero de bytes usados en cada linea de codigo.
   3. Los bytes de aqui, son el actual codigo hex de la instruccion fuente.  Lo maximo son 4 bytes.
       Si el codigo exede los 4 bytes el numero de bytes sera mostrado encerrado en corchetes cerrados. Esto es
        aparente cuendo se usa .INCBIN, .DCx, o .DSx.
   4. El Simbolo indica cualquier Label que ha sido asignado, se muestra en Mayuscula.
   5. El operador es la instruccion o Directiva de assembler, mostrado en mayuscula.
   6. El operando mustra la expresion en conjunto con el operador, mostrado en mayuscula.
   7. El Comentario comienza con un ; y luego el texto. 

La Tabla de Simbolos contiene una lista de simbolos definidos en el codigo fuente, seguido por sus valores.
los valores son mostrados en hex y decimal.  La tabla no incluye definiciones de uso de - y +.

EL archivo SMC es el archivo ejecutable de Super Magicom o mejor conocido como SNES.  La unica diferencia
con el archivo binario es que el SMC tiene una cabezera de 512 bytes al comienzo del archivo.


Simbolos
--------------
La tabla de simbolos es guardada en memoria y requiere 4 MB de XMS. Puedes usar un maximo de 
40960 simbolos. Esto incluyen los simbolos -, +, y @. Cada vez que se usan se cuenta como un simbolo.
40960 es mas que bueno, para tus programas.

Los nombres de los simbolos pueden ser de un maximo de 31 caracteres. Cualquier
simbolo creado con un valor y si ese simbolo ya existia, se sobreescribira 
con el nuevo valor. Un simbolo puede comenzar con cualquier letra de A a la Z 
o con underscore ( _ ).

Los simbolos especiales - y + pueden ser usados para saltos hacia atras o adelante.

Ejemplo:
CASO1
   -               lda     $4212       ; en esta direccion esta Status Register, espera por 
                                       ; vblank, Si A se carga por ejemplo 
                                       ; con 01000001 ->el bit 7 esta en 0
                   and     #$80        ; 80h = 10000000 bin -> bit 7 con 1, al hacer 
                                       ; AND entonces queda:   01000001
                                                          AND  10000000
                                                          --------------
                                                               00000000 => no son iguales el bit 7=0
                   beq     -           ; BEQ=Branch if Equal-> como no es 1, entonces no esta 
                                       ; en estado vblank, repite yendo a -

CASO2
                   lda     number
                   cmp     #1
                   bne     +
                   jmp     number_1
   +               cmp     #2
                   bne     +
                   jmp     number_2
   +               cmp     #3

En el primer caso del loop continuo, noes necesario crear un nuevo
simbolo para la rutina. En el segundo caso donde comparas una serie
de valores y la subrutina es demaciado lejana para saltar.

If you want to use nested - and + symbols you can use --,
---, ++, or +++.  Any symbols preceded with the - or +
symbols will be taken as the - or + symbol type.  So in
fact, you could use proper symbol names if you want to get
more detailed in your naming convention.

Temporary symbols, @ symbols, are now implemented and when
combined with the .MODULE directive come in very handy for
source codes which happen to use the same names as you.


Numbers and Expressions
-----------------------
Numbers can be in decimal, hexadecimal or binary.  All
hexadecimal numbers must start with the dollar sign ($).
Binary numbers are preceded with the percent sign (%).

   123                  decimal number
   $212,212h,$fa,0fah   hexadecimal number
   %101,101b            binary number

X816 supports the following arithmetic and logical operations.

   shift left number of bits            value SHL bits
                                        value << bits
   shift right number of bits           value SHR bits
                                        value >> bits
   logical AND                          value1 AND value2
                                        value1.AND.value2
                                        value1 && value2                                                ,,&&
   logical OR                           value1 OR value2
                                        value1.OR.value2
                                        value1 || value2
   logical XOR                          value1 XOR value2
                                        value1.XOR.value2

   multiplication                       *
   division                             /
   addition                             +
   subtraction                          -

All expressions are evaluated in the above order except
when parenthesis are used to force a higher priority of
evaluating an expression.  For example:

   6*3+8   = 26
   6*(3+8) = 66

Some of you use the {} symbols as parenthesis so the
directive .PAR can be used to change the parenthesis
types.

The use of the asterisk (*) as the current program address
has been added.  If the asterisk is used at the end of a
line it will assume this is a current address symbol.

   here =*
   length =*-start

A number can be modified using the symbols <, >, ^, and !
preceding the number or symbol.

   < get low byte
   > get high byte
   ^ get bank byte
   ! get word value

The use of the ^ or ! will only function if they are placed
at the beginning of the expression in the operand field.

   LDA  !512
   LDA  !$1234
   LDA  #!512
   LDA  #!$1234


Bitwidths
---------
As you know the 65816 can handle numbers in either 8- or
16-bit lengths.  An 8-bit number can have any value from
0-255 and a 16-bit number can have any value from 0-65535.
When X816 sees a number it automatically uses the lowest
bitwidth possible.  However, you can force the operand bit
length using the following extensions on the operator.

   .B  byte
   .W  word, 2 bytes
   .L  long, 3 bytes

In addition to using the forced bit length extensions the
use of the .MEM and .INDEX directives also control the bit
lengths when used with the accumulator and index registers.
Using .MEM 8 will force any use of the accumulator to be
in 8-bits.  .MEM 16 will force all accumulator use to be
16-bits.  Using the .INDEX directive does the same as .MEM
except it effects the use of index registers X and Y.

The use of the extensions will override the the .MEM and
.INDEX directives.

One other directive that affects the bit lengths, or rather
changes the .MEM and .INDEX directives is the .DETECT
directive which does autodetecting on the bit widths.  When
enabled X816 will change the bit lengths if a forced
extension is used or if a REP/SEP instruction is
encountered.  Keep in mind the detect only works with
a continuous flow of code so if subroutines are called,
the subroutines bit lengths may not be in sync with that
of the original routine that called it.


Assembler Directives
--------------------
.EQU (= or EQU)
Asigna un valor a un simbolo.
El valor del operando puede usar cualquier expresion soportada.
Ejemplo:
   espacio           .equ    $8F		;asigna el valor $8F al simbolo espacio

y luego usas:
   LDA  #espacio	   ;es lo mismo que hacer LDA #$8F


.ORG
Define la direccion de inicio.
Sets the starting address of the source file.  X816 will
not assemble any code until this directive is found.
Example:
                   .org    $808000

.DCB or .DB
Datos de bytes.
Create a table of byte size data from the operand.  The
operand should contain a list of byte values each separated
by a command.  If a value is greater than 8-bits only the
lower 8-bits will be used.
Examples:
                   .dcb    32,65,'A',$10,%100111
                   .dcb    "Hello there",0

.DCD or .DD
Datos de palabra doble (4 bytes).
Create a table of dword size data from the operand.  The
operand should contain a list of dword values each
separated by a command.  If a value is greater than 32-bits
only the lower 32-bits will be used.  All values will be
extended to a full 32-bits.
Example:
                   .dcd    $1234,%1110111,49152

.DCL or .DL
Datos de long (3 bytes).
Create a table of long size data from the operand.  The
operand should contain a list of long values each separated
by a command.  If a value is greater than 24-bits only the
lower 24-bits will be used.  All values will be extended to
a full 24-bits.
Example:
                   .dcl    $808000,$123456

.DCW or .DW
Datos de una palabra (2 bytes).
Create a table of word size data from the operand.  The
operand should contain a list of word values each separated
by a command.  If a value is greater than 16-bits only the
lower 16-bits will be used.  All values will be extended to
a full 16-bits.
Example:
                   .dcw    $1234,%1110111,49152

.DSB
Almacenamiento de bytes.
Creates a storage area of the number of bytes specified.
When the binary file is created the area will be filled
with zeros.
Example:
                   .dsb    32 ; create storage of 32 bytes

.DSD
Almacenamiento de palabras dobles (4 bytes).
Creates a storage area of the number of dwords specified.
When the binary file is created the area will be filled
with zeros.
Example:
                   .dsd    32 ; create storage of 32 dwords

.DSL
Almacenamiento de Longs (3 bytes).
Creates a storage area of the number of longs specified.
When the binary file is created the area will be filled
with zeros.
Example:
                   .dsl    32 ; create storage of 32 longs

.DSW
Almacenamiento de una palabra (2 bytes).
Creates a storage area of the number of words specified.
When the binary file is created the area will be filled
with zeros.
Example:
                   .dsw    32 ; create storage of 32 words

.PAD
Pad to address.
Fills the gap between the current address to the specified
address with zeros.  If used without any operand the source
will padded to the next bank, either starting at $xx0000 or
$xx8000 based on low/high ROM mode.  If in the low ROM mode
and the operand is lower than $8000 the directive will be
switched to a .DSB and the source will be filled with the
number of bytes specified in the operand.
Examples:
                   .pad            ; pad to next bank
                   .pad    $8500   ; pad to address $8500

.INCSRC (.SRC)
Include source.
Start assembling another source file into the current
source.  Once the included source is finished X816 will
continue with the previous source file.  You can nest up to
16 source files.
Example:
                   .incsrc "snesinit.asm"

.INCBIN (.BIN)
Include binary.
Include a binary file to the current address.  The source
code will be offset by the size of the binary file.
Example:
                   .incbin "gfx\font.bin"

.BASE
Set new base address.
In case you ever need to write relocatable code, such as
routines that go into WRAM, you can use this directive to
change the current address.  Once changed, X816 will
continue to assemble code but at this new address.  When
a .END directive is encountered X816 will restore itself
back to the address prior to the .BASE directive and
increase the address based on how many bytes were used
between .BASE and .END.  X816 is capable of nesting up to
32 .BASE directives.
Example:
                   .base   $7f8000
  delay            ldx     #$4000
  -                dex
                   bne     -
                   rts
                   .end

Warning, see the instructions on the .TABLE for more info.

.MEM
Define el ancho del acumulador. (por defecto es 16-bit)
Forces all subsequent use of the accumulator to either 8-
or 16-bits.  8 or 16 must be in the operand field.  If
neither is present X816 will report what bit length the
accumulator is being used as.  The bitlength can be
overridden using the bitlength extensions on the operator.
Examples:
                   .mem           ; report A bitlength
                   .mem    8      ; set A for 8-bit use
                   .mem    16     ; set A for 16-bit use

.INDEX
Define el ancho de los indices X e Y. (por defecto es 16-bit)
Forces all subsequent use of index registers X and Y to
either 8- or 16-bit.  8 or 16 must be in the operand field.
If neither is present X816 will report what bit length the
indexes are being used as.  The bitlength can be overidden
using the bitlength extensions on the operator.
Examples:
                   .index       ; report X/Y bitlength
                   .index  8    ; set X/Y to 8-bit use
                   .index  16   ; set X/Y to 16-bit use

.DETECT
Activa/Desactiva la deteci�n de cambios de ancho de bit. (Por defecto es Apagado)
X816 is capable of automatically detecting the changes in
bitlengths.  When enabled any use of forced bitlength
extensions or used of the REP/SEP instructions will change
the bit lengths for the accumulator and indexes within
the assembler.
Examples:
                   .detect     ; report detect on or off
                   .detect on  ; enable autodetection
                   .detect off ; disable autodetection

.DASM
Toggle assembly dusplay. (default off)
You have the option of showing the source listing as it is
being assembled during the final pass.  This comes in handy
when you're trying to track down a problem in part of your
source code.
Examples:
                   .dasm   on    ; show assembly
                   .dasm   off   ; don't show assembly

.OPTIMIZE (.OPT)
Activa la optimizaci�n de direcciones. (Por defecto es Apagado)
X816 is capable of detecting if an address is in the same
bank as the current address.  If this is true the address
can be truncated from its 24-bit value down to its 16-bit
value.  This will eliminate useless 24-bit references when
only a 16-bit address is necessary.  X816 will generate
errors when a reference to a 24-bit address is used when
the addressing mode is for 16-bit but the result binary
code will reflect the lower 16-bits of the address.
Examples:
                   .optimize     ; report optimize status
                   .optimize on  ; enable optimizing
                   .optimize off ; disable optimizing

.HROM
Modo High ROM. (por defecto esta en modo Low ROM)
Following code is assembled into 64 kb segments for use in
the SNESes mode 21.  If used this directive should be near
or at the beginning of the source code.
Example:
                   .hrom

.LROM
Low ROM mode. (default is low ROM mode)
Following code is assembled into 32 kb segments for use in
the SNESes mode 20.  If used this directive should be near
or at the beginning of the source code.
Example:
                   .lrom

.HIROM
Set ROM mode. (default is low ROM mode)
This directive is the same as the .HROM or .LROM directive.
Using ON or OFF in the operand sets either high ROM mode or
low ROM mode.  If no operand is used X816 reports what mode
is being used.  When toggling on or off X816 will attempt
to adjust the current address to the corresponding address
in either hirom or lorom mode.
Examples:
                   .hirom       ; report high ROM status
                   .hirom  on   ; use high ROM mode
                   .hirom  off  ; use low ROM mode

.SMC
Create Super Magicom file.
If a cartridge backup unit is used you will need to
generate an SMC executable file.  The use of this directive
will flag X816 to create an SMC file after the assembly
process is complete.  The only difference with the SMC
file is that it is padded to 32 kb segments and a 512 byte
header precedes the binary code.  The default filename is
the same as the source name except with the extension .SMC.
Examples:
                   .smc         ; write SMC file when done
                   .smc  "game.smc"; write SMC file with
                                   ; different name

.LIST
Generate source listing.
This is similiar to the -l option which tells X816 to
generate a listing.  The only difference is this allows
you to change the filename of the listing.
Examples:
                   .list        ; generating listing
                   .list "game.lst"; generate listing with
                                   ; a different name

.SYMBOL
Generate symbol listing.
This is similiar to the -$ option which tells X816 to
generate a symbol list.  The only difference is this allows
you to change the filename of the listing.
Examples:
                   .symbol       ; generating listing
                   .symbol "game.sym"; generate listing with
                                     ; a different name

.PARENTHESIS (.PAR)
Set parenthesis symbols.
This option allows you to define the parenthesis as either
() or {} for use with arithmetic expressions.  Any other
values in the operand will report what symbols are being
used.
Examples:
                   .parenthesis    ; report which symbols
                   .parenthesis () ; use ()
                   .parenthesis {} ; use {}

.ECHO
Echo text during assembly.
Any text following this directive will be printed to the
screen during pass 3 of the assembling process.  All text
will be converted to uppercase unless quotes are used
around the text.
Examples:
                   .echo   level 1
                   .echo   "Game Over"

.COMMENT
Display long comment during assembly.
When X816 encounters this directive all subsequent text
will be considered as a comment and is echoed to the
screen.  Only when the directive .END is found will X816
continue assembling the source code.  This enables one to
make a long comment without having to precede each line
with a semicolon (;).  The text is also echoed to the
screen during assembling.  The text will be displayed as it
is in the source file.
Example:
                   .comment
   This text will be displayed just as you see it here.
   Game Title: Super Smashem
                   .end

.INTERRUPTS (.INT)
Define interrupt vector table.
At the end of the first bank starting at $00ffe4 is a table
of interrupt vectors.  These interrupt vectors control what
to call when the reset is pressed, when vertical blank
occurs, and other processes that need to be serviced.  The
table has vectors for both native and emulation mode.  Once
all of your interrupt definitions are done you must end the
mode with a .END directive.  X816 maps the vectors to both
the native and emulation vectors.
There are only 5 vectors you can actually set.  You can
also set them all to the same address.
   all      Define all vectors to the same address.
   break    Called when the BRK instruction is used.
   coproc   Called when the COP #xx instruction is used.
   irq      Standard interrupt.  Effected by SEI/CLI.
   nmi      Non-maskable interrupt (NMI) which is wired to
            the vertical blank on the SNES.
   reset    Called when the reset button is pushed.
Use of this directive is optional.  If you do not use it
you should add in the reset vectors manually into your
source code.  Otherwise your code may not run when you test
it out.
Example:
                   .interrupts
   all             =       empty_irq
   nmi             =       vblank
   reset           =       restart
   break           =       hit_brk
   coproc          =       coproc_call
   irq             =       regular_irq
                   .end
   empty_irq       rti
   restart         jmp     $008000

.CARTRIDGE (.CART)
Define cartridge header.
At the the end of the first bank before the interrupt table
at $ffc0 is a 32 byte header containing information on the
cartridge.  This header defines the cartridge title, ROM
mode, cartridge type, ROM size, RAM size, country code,
maker/company, version, checksum and checksum compliment.
X816 allows you to define all of it except the checksum and
checksum compliment.  All values are bytes except the title
which can be up to 21 characters.  Once you've finished
setting the header use a .END directive to return bank to
assembly mode.  Below are some specs for each parameter.

        TITLE   21 character ASCII text for the cartridge
                title.  This area should be padded with
                spaces.
        MODE    The map mode which the cartridge uses.
                This determines whether the cartridge is
                HIROM and what CPU speed is to be used.
                   $20 = mode 20, standard speed
                   $21 = mode 21, standard speed
                   $30 = mode 20, high speed
                   $31 = mode 21, high speed
        TYPE    Cartridge type.
                   $00 = ROM only
                   $01 = ROM + RAM
                   $02 = ROM + Backup RAM
                   $03 = ROM + DSP
                   $04 = ROM + DSP + RAM
                   $05 = ROM + DSP + Backup RAM
        ROMSIZE ROM size.
                   $09 = 4 MBits
                   $0a = 8 MBits
                   $0b = 16 MBits
                   $0c = 32 MBits
        RAMSIZE RAM size.
                   $00 = RAM not used
                   $01 = 16 KBits
                   $02 = 32 KBits
                   $03 = 64 KBits
                   $04 = 128 KBits
                   $05 = 256 KBits
        COUNRTY Country code.
                   $00 = Japan
                   $01 = America
                   $02 = PAL Video
                   $03 = Sweden
                   $04 = Finland
                   $05 = Denmark
                   $06 = France
                   $07 = Holland
                   $08 = Spain
                   $09 = Germany
                   $0a = Italy
                   $0b = China
                   $0c = India
                   $0d = Korea
        MAKER   Company that makes the cartridge.
                This list is much to long to include.
                Just use $00 for an undefined company.
        VERSION ROM version number.

Example:
                   .cartridge
   title           =       "Super Smashem"
   mode            =       $00
   type            =       $02
   romsize         =       $0b
   ramsize         =       $03
   country         =       $01
   maker           =       $00
   version         =       $00
                   .end

.IF
Compare two constants for conditional assembly.
Two constants are compared and if the result is true the
following code is assembled up to an .ENDIF or .ELSE
directive.   X816 supports only seven expressions for
comparison of the two constants.
   c1        true if c1 is not equal to zero
   c1 = c2   true if c1 is equal to c2
   c1 > c2   true if c1 is greater than c2
   c1 < c2   true if c1 is less than c2
   c1 >= c2  true if c1 is greater than or equal to c2
   c1 <= c2  true if c1 is less than or equal to c2
   c1 <> c2  true if c1 is not equal to c2
You can nest up to 255 .IF directives.
Example:
   flag1           =       32
   flag2           =       4*8
                   .if     flag1 = flag2
                   .echo   "flag1 is equal to flag2"
                   .endif

.ELSE
Failure of compare for conditional assembly.
When the two constants are compared and found false the
assembling process will continue starting at the .ELSE
directive, if there is one.  The use of .ELSE is optional.
X816 will continue assembling up to and .ENDIF directive
which marks the end of the conditional assembly block which
was started with the .IF directive.
Example:
   flag1           =       32
   flag2           =       4*8
                   .if     flag1 = flag2
                   .echo   "flag1 is equal to flag2"
                   .else
                   .echo   "flag1 is not equal to flag2"
                   .endif

.ENDIF
End of conditional assembly block.
The end of the conditional assembly block started by the
.IF directive is marked with this directive.  Failure to
mark the end with an .ENDIF could have some hurrendous
results on your binary code.
Examples:
   flag1           =       32
   flag2           =       4*8
                   .if     flag1 = flag2
                   .echo   "flag1 is equal to flag2"
                   .endif
   flag1           =       32
   flag2           =       4*8
                   .if     flag1 = flag2
                   .echo   "flag1 is equal to flag2"
                   .else
                   .echo   "flag1 is not equal to flag2"
                   .endif

.IFDEF
If defined conditional assembly.
Checks to see whether the constant was defined in the
source code.  If the constant was defined X816 will
continue assembling up to and .ELSE or .ENDIF.  If the
constant was not defined X816 will look for an .ELSE or
.ENDIF.

.IFNDEF
If not defined conditional assembly.
This is the opposite of the .IFDEF.  It checks whether or
not a constant was not defined.  It the constant was not
defined then X816 will continue to assemble up to an .ELSE
or .ENDIF.  If the constant was defined with X816 will
continue at an .ELSE or look for the .ENDIF.

.MACRO
Define a macro.
The macro directive sets up a block of repetitive code that
has only minor changes such as different values.  Once a
macro has been defined the source code within that macro
can be inserted at any point in the source simply by using
the macro name preceded with a period (.) as an operator.
Parameters to be passed in a macro must be enclosed with
parenthesis and each parameter separated by a comma.  Up to
32 parameters may be passed to a macro.
Example:
                   .org    $8000
   storetext       .macro  (TEXT)
                   jmp     +
                   .dcb    "TEXT",0
   +
                   .endm
                   .storetext ("Minus-Media")
                   rts

     1 008000                              .ORG   $8000
     2 008000 [macro]     STORETEXT        .MACRO (TEXT)
     3 008000 [macro]                      JMP    +
     4 008000 [macro]                      .DCB   "TEXT",0
     5 008000 [macro]     +
     6 008000                              .ENDM
     7 008000                              .STORETEXT ("Minus-Media")
     3 008000 4C 0F 80                     JMP    +
     4 008003 [00000C]                     .DCB   "Minus-Media",0
     5 00800F             +
     6 00800F                              .ENDM
     8 00800F 60                           RTS

You may nest upto 16 macros within one another.  The
parameter names passed in the macro should be no longer
than 31 characters.  Actual symbols can be used when
calling a macro, in which case the corresponding value
will be used.  Only the label, operator and operand fields
are scanned for any of the parameter names.

One final note to remember is that the operator field
is capitalized except for text appearing within quotes,
so make sure you use the proper casing in your macros.

.MODULE (.MOD)
Defines a new module.
All symbols preceded with a local symbol character such as
-, +, or @ are defined as local symbols.  These symbols are
only accessible within the same module they are defined.
The use of the .MODULE directive allows you to assign a new
module name, effectively clearing any previous local
symbols you may have used earlier in your source code.
Example:
                   .module xxx
                   ldx     #0
   @loop           dex
                   bne     @loop
                   rts
                   .module yyy
                   ldy     #0
   @loop           dey
                   bne     @loop
                   rts

If you try to assemble the above code no errors will occur
even though the same symbol name is used twice.  Removing
the .module yyy and reassembling will generate a duplicate
symbol error because the same symbol name was used earlier.

The default character for the local symbol character is @
but this can be changed using the .LOCALSYMBOLCHAR
directive.  If you do change the character make sure you
use a unique character.

.LOCALSYMBOLCHAR (.LOCCHAR)
Define local symbol character.
The local symbol character is the character used at the
beginning of a symbol name to signify it is only used
within the current module.  The default character is the
'@' symbol.  Be careful to choose a unique character that
will not disrupt the assembler.
Example:
                   .LOCALSYMBOLCHAR "_"
   _loop           dey
                   bne     _loop

Redefines the local symbol character as '_',
the underscore.

.ASCTABLE
Define ASC table.
Graphic tiles do not always line up with your standard
ASCII table and need to be modified manually or with an
extra routine.  This directive allows you to have X816
automatically reassign those ASC values while it is
assembling.  When you have completed all your definitions
you need to mark the end with the .END directive.

For example the letter 'A' has an ASCII value of 65 but in
your tileset the letter 'A' is assigned to tile #1.  You
could reassign the letter 'A' to 1 instead of 65.
Example:
                   .asctable
   65              =       1
                   .end

You may also set a range of values instead of doing each
character one at a time.
Example:
                   .asctable
   cleartable
   "A".."Z"        =       1
                   .end

The example above will assign letters 'A' to 'Z' with 'A'
starting at 1 and 'Z' ending at 27.

Only values from 0 to 255 are accepted.  Any other values
will generate an error.

The ASC table is cleared at the beginning of each pass and
may also be cleared at anytime during the assembling
process by using the statement CLEARTABLE or just CLEAR
while in the ASC definition mode.  This command has been
added so that the ASC table can be redefined any time in
the source code.

A seperate directive is setup to use the ASC table rather
than the standard .DCB directive.  Only the .ASC directive
will make use of the ASC table.

.ASC
Text data remapped with ASC table.
This directive is similiar to the .DCB directive with one
little change.  All bytes of data parsed in the operand
field are remapped to the corresponding value in the
ASC table, defined with the directive .ASCTABLE.  This will
allow you to automatically reorder your text to match your
tiles without having to do it manually with a series of
numbers.
Example:
                   .asctable
   "0".."9"        =       0
   "A".."Z"        =       10
                   .end
                   .asc    "HELLO"

The resulting data would be 18,15,22,22,25.

All values in the ASC table are set to 0 so if an ASC value
is not set it will be 0.

.TABLE (.TAB)
Set data table address.
This directive is similiar to the .BASE directive with only
one exception, no data is actually output between .TABLE
and .END.  The primary use for .TABLE is to quickly create
data tables or records.
Example:
                   .table  $0100
  temp1            .dcb    0
  temp2            .dcw    0,0
  temp3            .dsb    32
  temp4            .dsw    1
                   .end

In the above example temp1 would equal $100, temp2 equals
$101, temp3 equals $103 and temp4 equals $123.  The address
range from temp1 to the end of temp4 would be $100-$124.
Doing it the old way would look like this:
  temp1            =       $100
  temp2            =       temp1+1
  temp3            =       temp2+2
  temp4            =       temp3+32

You can see the advantages when you need to add in extra
space between labels.

One warning about the .TABLE directive, it uses the same
set of variable space and routines as .BASE.  The maximum
number of .BASE and .TABLE you can nest has been increased
to 32 from 16.  As well you shouldn't use a .BASE within a
.TABLE ... .END since this may knock your code out of
alignment.  It's more than likely you will not do this in
the first place.


Technical Notes
---------------
X816 is written in Turbo Pascal.
Maximum 31 characters per symbol name.
Maximum 40960 symbols.
Maximum 32768 modules.
Up to 255 if conditional directives can be nested.
Up to 16 macros can be nested.
Up to 32 parameters may be passed in a macro.
Up to 16 source includes can be nested.
Up to 32 base addresses can be nested.


Related Points of Interest
--------------------------
So you're interested in learning about the SNES or maybe
even programming on it?  Well here's a few sites that may
be of interest to you.

   http://minus.parodius.com
      Look me up at my own site.  This is where you can
      find most of my work, including new updates to
      X816!  Check it out.

   http://www.anthrox.com/
      Anybody who owns a copier knows Anthrox.  The group
      has put up their own web page with a section
      dedicated to SNES programming.  Includes source
      codes to some of their intros and trainers.


Closing Words
-------------
Look for some of these on my homepage!

        Modular Escape demo - Christmas demo with a
                jukebox that plays various songs
                converted from the MOD format.
        F4CG intro - an intro screen for the Fantastic
                Four Cracking Group that was never used.
        Titans experiment - a nifty Titans sword logo
                using the rotating function in mode 7.
        Zoomer - found in the Tricks Assembler which
                does some zooming/rotating in mode 7.

As always I'd like to see what you've made for the SNES.
Just uuencode to me a copy of your final product or catch
me on IRC channel #emu or #mpeg3.  All work sent to me
will be kept confidential.

                                     minus@smartt.com

