X816 assembler v1.12f.19970408
by minus/Ballistics, email: minus@smartt.com

04/08/97 - v1.12f
           Added directive .TABLE.
           Fixed duplicate first symbol name problem.
01/10/97 - v1.12e
           Added directive .ASCTABLE.
           Added directive .ASC.
           Fixed bug with .IFDEF and .IFNDEF.
           Changed the .CARTRIDGE parameter names.
              (see the docs for details)
11/29/96 - v1.12d
           Added .SMC <filename>.
           Added .LIST <filename>.
           Added .SYMBOL <filename>.
           Added directive .DW for .DCW.
           Added directive .DL for .DCL.
           Added directive .DD for .DCD.
           Added current address symbol (*).
           Added 0xxxh for hex numbers.
           Added 0xxxb for binary numbers.
           Added directive .MODULE/.MOD.
           Added optimize JSR/JMP address in same bank.
           Fixed misaligned start address problem.
           Fixed missing errors on illegal absolute long.
           Fixed .PAR for use with arithmetic expressions.
           Fixed .HIROM to adjust current address.
           Fixed .MACRO lockup with no parameters.
           Rewrote source loading routine.
           Rewrote equation parsing routine.
           Rewrote symbol searching/sort.
           Removed use of ^ modifier for logical XOR.
           Adjusted logical operations.
09/01/96 - v1.11
           Added directive .DB for .DCB.
           Added instruction COP.
           Added instruction WDM.
           Fixed instruction BRK to accept operand.
           Fixed error message with .SRC/.INCSRC.
           Fixed .BASE addressing problems.
           Added ^ modifier for getting bank address byte.
           Added ! modifier for getting word value or
              forcing absolute addressing.
           Added instruction INA for INC A.
           Added instruction DEA for DEC A.
06/05/96 - v1.10
           Source code rewritten.
           Requires 4 MB of XMS memory.
           Source files are loaded into XMS.
           Total of all source files cannot exceed 2 MB.
           Symbols are stored in XMS, requires 2 MB.
           Symbol table sorted alphabetically for speed.
           Sub instruction per code line removed.
           Removed use of @ symbols.
           Added macro capabilities.
01/19/96 - v1.04
           Fixed problem with PEA.
           Fixed runtime error caused by use of interrupt
              table when binary file is less than 32 kb.
           Directive ".INTERRUPT" is now ".INTERRUPTS".
12/28/95 - v1.01
           Additional info on - and + symbols.
           Added @ symbol types.
12/24/95 - v1.00


Notes From The Author - 03/14/96
--------------------------------
Check out my web page at http://minus.parodius.com.
Thanks to Y0shi for the web space!  And don't forget my
new email address.
                                     minus@smartt.com


Introduction
------------
X816 is an assembler that generates machine code for the
Super NES, or more specifically the 65816.  X816 is based
mainly on the assemblers seen on the C64/128 but with a few
additions to bring it up to speed for the SNES.

X816 supports the complete 65816 instruction set and all of
its addressing modes.  As well, a set of assembler
directives are included to make the programmers job a bit
more easier.  X816 will take any source code stored in a
standard text file and generate binary code.


Disclaimer
----------
X816 is public domain software.  What you do with it is up
to you.  The author is not liable for any damages it may
cause.  Feel free to send the original archive to all of
your friends, BBSs and Internet sites.


Running X816
------------
To assemble your source code simply type X816 followed by
the filename of the source file and press <Enter>.  There
are a few options that can be enabled on the command line
before assembling.  Below is a a summary of how to assemble
a source file and the options available.

   usage: X816 [-option] <source[.asm|.src|.s]>
   option:
    $: generate symbol file
    d: display assembly
    l: generate listing
    s: make smc file

There are only a handful of options available at the
command line level.  All of the above options are initially
disabled.  To enable any of the options simply include the
corresponding letter in the options part of the command
line.  More options can be set within the source code by
using the assembler directives.

Once given a proper source code filename X816 will begin
assembling the source code.  X816 makes 3 passes through
the source code.  The first and second pass save the
addresses or values of symbols.  The third pass is when the
binary file is written.  If any errors are found they will
be displayed in the final pass.


Source Code Formatting
----------------------
Before any actual code can be generated the source file
must set the origin address.  If any code is encountered
prior to the setting of the origin address the assembler
will exit on a fatal error.

Your source code files should be saved in standard ASCII
text.  Most people code using a single instruction per
line.  This makes it easier to read your code.  X816 gives
you the option of using a colon (:) or a backwards slash
(\) to separate multiple instructions on a line.  However,
certain restrictions are imposed when multiple instructions
are used on a line.

X816 sees a line of source code in four fields.

   Label      Operator      Operand     Comment
   start      lda           #32         ; load 32 into .A
              .dcb          32,45,67    ; data values
              iny
              inc           $1000

Not all of the fields need to be used.  Any text after the
comment is ignored so do not try to put multiple
instructions after a comment.  Here's an example of
multiple instructions on a line.

   lda $1000 : cmp #$16 : bne forward ; Check $1000 against #$16

Spaces should precede and follow the separation symbol.
The backwards slash may also be used to separate multiple
instructions.


Output Files
------------
Only a binary file is written when a source file is
assembled.  Other files that may be saved are a symbol
table, assembly listing, and a Super Magicom executable
file.

   BIN   - binary file
   LST   - assembly listing
   SYM   - symbol table listing
   SMC   - Super Magicom executable file

A temporary file may also be written to disk when the
symbol table is generated on disk rather than in memory.

The binary file is the actual product of the assembling
process.

The assembly listing file is the actual output of the
assembling process.  It shows the line numbers, bytes of
code, and the source lines split into their 4 fields.  The
listing follows the below format.

1          2       3        4      5        6       7
Statement  Address Byte#1-4 Symbol Operator Operand Comment

   1. The statement number keeps track of the an individual
      line of code.  Blank lines are considered statements.
   2. Current address of the line.  This is increased based
      on the number of bytes used to make up each line of
      code.
   3. The bytes represented here is the actual hex code of
      the source instruction.  This field is a maximum of
      4 bytes.  If the code exceeds 4 bytes the number of
      bytes will be displayed enclosed in brackets.  This
      is apparent when .INCBIN, .DCx, or .DSx is used.
   4. The symbol field contains any labels being assigned.
      This is convertted to uppercase.
   5. The operator is the instruction or assembler
      directive.  This is convertted to uppercase.
   6. The operand contains expressions which are used in
      conjunction with the operator.  This is convertted to
      uppercase.
   7. The comment field starts with a semicolon (;) and is
      followed by text.  This field remains in the same
      casing as in the source file.

The symbol table listing contains a list of the symbols
defined in the source code followed by their values.  The
values are show in both hex and decimal.  The table does
not include the use of the - and + definitions.

The SMC file is the Super Magicom executable file.  All
backup units are capable of using this file type.  The only
difference between this file and the binary file is that
there is a 512 byte header attached to the beginning of
binary file.


Symbols
-------
The symbol table is stored in memory and requires 4 MB of
XMS.  A maximum of 40960 symbols may be used.  This
includes the use of -, +, and @ symbols.  Each time one of
these is used, so is a symbol.  40960 should be more than
adequate for most programs.

Symbol names can be a maximum of 31 characters.  Any
symbols sharing the same name will be overwritten with the
newer value.  A symbol can start with any letter from
A to Z or with the underscore (_).

Special symbols - and + can be used for reverse and forward
branches.  These two symbols come in very handy as you will
see.

Examples:
   -               lda     $4212       ; wait for vblank
                   and     #$80        ; bit 7
                   beq     -           ; not vblank, repeat

                   lda     number
                   cmp     #1
                   bne     +
                   jmp     number_1
   +               cmp     #2
                   bne     +
                   jmp     number_2
   +               cmp     #3

In the first case of a continuous loop like in the first
example you don't need to create a new symbol name for the
routine.  In the second case where you're comparing a
series of values and the subroutine is too far to branch.

If you want to use nested - and + symbols you can use --,
---, ++, or +++.  Any symbols preceded with the - or +
symbols will be taken as the - or + symbol type.  So in
fact, you could use proper symbol names if you want to get
more detailed in your naming convention.

Temporary symbols, @ symbols, are now implemented and when
combined with the .MODULE directive come in very handy for
source codes which happen to use the same names as you.


Numbers and Expressions
-----------------------
Numbers can be in decimal, hexadecimal or binary.  All
hexadecimal numbers must start with the dollar sign ($).
Binary numbers are preceded with the percent sign (%).

   123                  decimal number
   $212,212h,$fa,0fah   hexadecimal number
   %101,101b            binary number

X816 supports the following arithmetic and logical operations.

   shift left number of bits            value SHL bits
                                        value << bits
   shift right number of bits           value SHR bits
                                        value >> bits
   logical AND                          value1 AND value2
                                        value1.AND.value2
                                        value1 && value2                                                ,,&&
   logical OR                           value1 OR value2
                                        value1.OR.value2
                                        value1 || value2
   logical XOR                          value1 XOR value2
                                        value1.XOR.value2

   multiplication                       *
   division                             /
   addition                             +
   subtraction                          -

All expressions are evaluated in the above order except
when parenthesis are used to force a higher priority of
evaluating an expression.  For example:

   6*3+8   = 26
   6*(3+8) = 66

Some of you use the {} symbols as parenthesis so the
directive .PAR can be used to change the parenthesis
types.

The use of the asterisk (*) as the current program address
has been added.  If the asterisk is used at the end of a
line it will assume this is a current address symbol.

   here =*
   length =*-start

A number can be modified using the symbols <, >, ^, and !
preceding the number or symbol.

   < get low byte
   > get high byte
   ^ get bank byte
   ! get word value

The use of the ^ or ! will only function if they are placed
at the beginning of the expression in the operand field.

   LDA  !512
   LDA  !$1234
   LDA  #!512
   LDA  #!$1234


Bitwidths
---------
As you know the 65816 can handle numbers in either 8- or
16-bit lengths.  An 8-bit number can have any value from
0-255 and a 16-bit number can have any value from 0-65535.
When X816 sees a number it automatically uses the lowest
bitwidth possible.  However, you can force the operand bit
length using the following extensions on the operator.

   .B  byte
   .W  word, 2 bytes
   .L  long, 3 bytes

In addition to using the forced bit length extensions the
use of the .MEM and .INDEX directives also control the bit
lengths when used with the accumulator and index registers.
Using .MEM 8 will force any use of the accumulator to be
in 8-bits.  .MEM 16 will force all accumulator use to be
16-bits.  Using the .INDEX directive does the same as .MEM
except it effects the use of index registers X and Y.

The use of the extensions will override the the .MEM and
.INDEX directives.

One other directive that affects the bit lengths, or rather
changes the .MEM and .INDEX directives is the .DETECT
directive which does autodetecting on the bit widths.  When
enabled X816 will change the bit lengths if a forced
extension is used or if a REP/SEP instruction is
encountered.  Keep in mind the detect only works with
a continuous flow of code so if subroutines are called,
the subroutines bit lengths may not be in sync with that
of the original routine that called it.


Assembler Directives
--------------------
.EQU (= or EQU)
Assign value to a symbol.
The value in the operand can use any of the supported
expressions.
Examples:
   space           .equ    32
   letter_a        =       65

.ORG
Define origin address.
Sets the starting address of the source file.  X816 will
not assemble any code until this directive is found.
Example:
                   .org    $808000

.DCB or .DB
Data of bytes.
Create a table of byte size data from the operand.  The
operand should contain a list of byte values each separated
by a command.  If a value is greater than 8-bits only the
lower 8-bits will be used.
Examples:
                   .dcb    32,65,'A',$10,%100111
                   .dcb    "Hello there",0

.DCD or .DD
Data of double words (4 bytes).
Create a table of dword size data from the operand.  The
operand should contain a list of dword values each
separated by a command.  If a value is greater than 32-bits
only the lower 32-bits will be used.  All values will be
extended to a full 32-bits.
Example:
                   .dcd    $1234,%1110111,49152

.DCL or .DL
Data of long (3 bytes).
Create a table of long size data from the operand.  The
operand should contain a list of long values each separated
by a command.  If a value is greater than 24-bits only the
lower 24-bits will be used.  All values will be extended to
a full 24-bits.
Example:
                   .dcl    $808000,$123456

.DCW or .DW
Data of word (2 bytes).
Create a table of word size data from the operand.  The
operand should contain a list of word values each separated
by a command.  If a value is greater than 16-bits only the
lower 16-bits will be used.  All values will be extended to
a full 16-bits.
Example:
                   .dcw    $1234,%1110111,49152

.DSB
Storage of bytes.
Creates a storage area of the number of bytes specified.
When the binary file is created the area will be filled
with zeros.
Example:
                   .dsb    32 ; create storage of 32 bytes

.DSD
Storage of double words (4 bytes).
Creates a storage area of the number of dwords specified.
When the binary file is created the area will be filled
with zeros.
Example:
                   .dsd    32 ; create storage of 32 dwords

.DSL
Storage of longs (3 bytes).
Creates a storage area of the number of longs specified.
When the binary file is created the area will be filled
with zeros.
Example:
                   .dsl    32 ; create storage of 32 longs

.DSW
Storage of words (2 bytes).
Creates a storage area of the number of words specified.
When the binary file is created the area will be filled
with zeros.
Example:
                   .dsw    32 ; create storage of 32 words

.PAD
Pad to address.
Fills the gap between the current address to the specified
address with zeros.  If used without any operand the source
will padded to the next bank, either starting at $xx0000 or
$xx8000 based on low/high ROM mode.  If in the low ROM mode
and the operand is lower than $8000 the directive will be
switched to a .DSB and the source will be filled with the
number of bytes specified in the operand.
Examples:
                   .pad            ; pad to next bank
                   .pad    $8500   ; pad to address $8500

.INCSRC (.SRC)
Include source.
Start assembling another source file into the current
source.  Once the included source is finished X816 will
continue with the previous source file.  You can nest up to
16 source files.
Example:
                   .incsrc "snesinit.asm"

.INCBIN (.BIN)
Include binary.
Include a binary file to the current address.  The source
code will be offset by the size of the binary file.
Example:
                   .incbin "gfx\font.bin"

.BASE
Set new base address.
In case you ever need to write relocatable code, such as
routines that go into WRAM, you can use this directive to
change the current address.  Once changed, X816 will
continue to assemble code but at this new address.  When
a .END directive is encountered X816 will restore itself
back to the address prior to the .BASE directive and
increase the address based on how many bytes were used
between .BASE and .END.  X816 is capable of nesting up to
32 .BASE directives.
Example:
                   .base   $7f8000
  delay            ldx     #$4000
  -                dex
                   bne     -
                   rts
                   .end

Warning, see the instructions on the .TABLE for more info.

.MEM
Define accumulator bitwidth. (default is 16-bit)
Forces all subsequent use of the accumulator to either 8-
or 16-bits.  8 or 16 must be in the operand field.  If
neither is present X816 will report what bit length the
accumulator is being used as.  The bitlength can be
overridden using the bitlength extensions on the operator.
Examples:
                   .mem           ; report A bitlength
                   .mem    8      ; set A for 8-bit use
                   .mem    16     ; set A for 16-bit use

.INDEX
Define index bitwidth. (default is 16-bit)
Forces all subsequent use of index registers X and Y to
either 8- or 16-bit.  8 or 16 must be in the operand field.
If neither is present X816 will report what bit length the
indexes are being used as.  The bitlength can be overidden
using the bitlength extensions on the operator.
Examples:
                   .index       ; report X/Y bitlength
                   .index  8    ; set X/Y to 8-bit use
                   .index  16   ; set X/Y to 16-bit use

.DETECT
Toggle bitlength detection. (default is off)
X816 is capable of automatically detecting the changes in
bitlengths.  When enabled any use of forced bitlength
extensions or used of the REP/SEP instructions will change
the bit lengths for the accumulator and indexes within
the assembler.
Examples:
                   .detect     ; report detect on or off
                   .detect on  ; enable autodetection
                   .detect off ; disable autodetection

.DASM
Toggle assembly dusplay. (default off)
You have the option of showing the source listing as it is
being assembled during the final pass.  This comes in handy
when you're trying to track down a problem in part of your
source code.
Examples:
                   .dasm   on    ; show assembly
                   .dasm   off   ; don't show assembly

.OPTIMIZE (.OPT)
Toggle address optimize. (default is off)
X816 is capable of detecting if an address is in the same
bank as the current address.  If this is true the address
can be truncated from its 24-bit value down to its 16-bit
value.  This will eliminate useless 24-bit references when
only a 16-bit address is necessary.  X816 will generate
errors when a reference to a 24-bit address is used when
the addressing mode is for 16-bit but the result binary
code will reflect the lower 16-bits of the address.
Examples:
                   .optimize     ; report optimize status
                   .optimize on  ; enable optimizing
                   .optimize off ; disable optimizing

.HROM
High ROM mode. (default is low ROM mode)
Following code is assembled into 64 kb segments for use in
the SNESes mode 21.  If used this directive should be near
or at the beginning of the source code.
Example:
                   .hrom

.LROM
Low ROM mode. (default is low ROM mode)
Following code is assembled into 32 kb segments for use in
the SNESes mode 20.  If used this directive should be near
or at the beginning of the source code.
Example:
                   .lrom

.HIROM
Set ROM mode. (default is low ROM mode)
This directive is the same as the .HROM or .LROM directive.
Using ON or OFF in the operand sets either high ROM mode or
low ROM mode.  If no operand is used X816 reports what mode
is being used.  When toggling on or off X816 will attempt
to adjust the current address to the corresponding address
in either hirom or lorom mode.
Examples:
                   .hirom       ; report high ROM status
                   .hirom  on   ; use high ROM mode
                   .hirom  off  ; use low ROM mode

.SMC
Create Super Magicom file.
If a cartridge backup unit is used you will need to
generate an SMC executable file.  The use of this directive
will flag X816 to create an SMC file after the assembly
process is complete.  The only difference with the SMC
file is that it is padded to 32 kb segments and a 512 byte
header precedes the binary code.  The default filename is
the same as the source name except with the extension .SMC.
Examples:
                   .smc         ; write SMC file when done
                   .smc  "game.smc"; write SMC file with
                                   ; different name

.LIST
Generate source listing.
This is similiar to the -l option which tells X816 to
generate a listing.  The only difference is this allows
you to change the filename of the listing.
Examples:
                   .list        ; generating listing
                   .list "game.lst"; generate listing with
                                   ; a different name

.SYMBOL
Generate symbol listing.
This is similiar to the -$ option which tells X816 to
generate a symbol list.  The only difference is this allows
you to change the filename of the listing.
Examples:
                   .symbol       ; generating listing
                   .symbol "game.sym"; generate listing with
                                     ; a different name

.PARENTHESIS (.PAR)
Set parenthesis symbols.
This option allows you to define the parenthesis as either
() or {} for use with arithmetic expressions.  Any other
values in the operand will report what symbols are being
used.
Examples:
                   .parenthesis    ; report which symbols
                   .parenthesis () ; use ()
                   .parenthesis {} ; use {}

.ECHO
Echo text during assembly.
Any text following this directive will be printed to the
screen during pass 3 of the assembling process.  All text
will be converted to uppercase unless quotes are used
around the text.
Examples:
                   .echo   level 1
                   .echo   "Game Over"

.COMMENT
Display long comment during assembly.
When X816 encounters this directive all subsequent text
will be considered as a comment and is echoed to the
screen.  Only when the directive .END is found will X816
continue assembling the source code.  This enables one to
make a long comment without having to precede each line
with a semicolon (;).  The text is also echoed to the
screen during assembling.  The text will be displayed as it
is in the source file.
Example:
                   .comment
   This text will be displayed just as you see it here.
   Game Title: Super Smashem
                   .end

.INTERRUPTS (.INT)
Define interrupt vector table.
At the end of the first bank starting at $00ffe4 is a table
of interrupt vectors.  These interrupt vectors control what
to call when the reset is pressed, when vertical blank
occurs, and other processes that need to be serviced.  The
table has vectors for both native and emulation mode.  Once
all of your interrupt definitions are done you must end the
mode with a .END directive.  X816 maps the vectors to both
the native and emulation vectors.
There are only 5 vectors you can actually set.  You can
also set them all to the same address.
   all      Define all vectors to the same address.
   break    Called when the BRK instruction is used.
   coproc   Called when the COP #xx instruction is used.
   irq      Standard interrupt.  Effected by SEI/CLI.
   nmi      Non-maskable interrupt (NMI) which is wired to
            the vertical blank on the SNES.
   reset    Called when the reset button is pushed.
Use of this directive is optional.  If you do not use it
you should add in the reset vectors manually into your
source code.  Otherwise your code may not run when you test
it out.
Example:
                   .interrupts
   all             =       empty_irq
   nmi             =       vblank
   reset           =       restart
   break           =       hit_brk
   coproc          =       coproc_call
   irq             =       regular_irq
                   .end
   empty_irq       rti
   restart         jmp     $008000

.CARTRIDGE (.CART)
Define cartridge header.
At the the end of the first bank before the interrupt table
at $ffc0 is a 32 byte header containing information on the
cartridge.  This header defines the cartridge title, ROM
mode, cartridge type, ROM size, RAM size, country code,
maker/company, version, checksum and checksum compliment.
X816 allows you to define all of it except the checksum and
checksum compliment.  All values are bytes except the title
which can be up to 21 characters.  Once you've finished
setting the header use a .END directive to return bank to
assembly mode.  Below are some specs for each parameter.

        TITLE   21 character ASCII text for the cartridge
                title.  This area should be padded with
                spaces.
        MODE    The map mode which the cartridge uses.
                This determines whether the cartridge is
                HIROM and what CPU speed is to be used.
                   $20 = mode 20, standard speed
                   $21 = mode 21, standard speed
                   $30 = mode 20, high speed
                   $31 = mode 21, high speed
        TYPE    Cartridge type.
                   $00 = ROM only
                   $01 = ROM + RAM
                   $02 = ROM + Backup RAM
                   $03 = ROM + DSP
                   $04 = ROM + DSP + RAM
                   $05 = ROM + DSP + Backup RAM
        ROMSIZE ROM size.
                   $09 = 4 MBits
                   $0a = 8 MBits
                   $0b = 16 MBits
                   $0c = 32 MBits
        RAMSIZE RAM size.
                   $00 = RAM not used
                   $01 = 16 KBits
                   $02 = 32 KBits
                   $03 = 64 KBits
                   $04 = 128 KBits
                   $05 = 256 KBits
        COUNRTY Country code.
                   $00 = Japan
                   $01 = America
                   $02 = PAL Video
                   $03 = Sweden
                   $04 = Finland
                   $05 = Denmark
                   $06 = France
                   $07 = Holland
                   $08 = Spain
                   $09 = Germany
                   $0a = Italy
                   $0b = China
                   $0c = India
                   $0d = Korea
        MAKER   Company that makes the cartridge.
                This list is much to long to include.
                Just use $00 for an undefined company.
        VERSION ROM version number.

Example:
                   .cartridge
   title           =       "Super Smashem"
   mode            =       $00
   type            =       $02
   romsize         =       $0b
   ramsize         =       $03
   country         =       $01
   maker           =       $00
   version         =       $00
                   .end

.IF
Compare two constants for conditional assembly.
Two constants are compared and if the result is true the
following code is assembled up to an .ENDIF or .ELSE
directive.   X816 supports only seven expressions for
comparison of the two constants.
   c1        true if c1 is not equal to zero
   c1 = c2   true if c1 is equal to c2
   c1 > c2   true if c1 is greater than c2
   c1 < c2   true if c1 is less than c2
   c1 >= c2  true if c1 is greater than or equal to c2
   c1 <= c2  true if c1 is less than or equal to c2
   c1 <> c2  true if c1 is not equal to c2
You can nest up to 255 .IF directives.
Example:
   flag1           =       32
   flag2           =       4*8
                   .if     flag1 = flag2
                   .echo   "flag1 is equal to flag2"
                   .endif

.ELSE
Failure of compare for conditional assembly.
When the two constants are compared and found false the
assembling process will continue starting at the .ELSE
directive, if there is one.  The use of .ELSE is optional.
X816 will continue assembling up to and .ENDIF directive
which marks the end of the conditional assembly block which
was started with the .IF directive.
Example:
   flag1           =       32
   flag2           =       4*8
                   .if     flag1 = flag2
                   .echo   "flag1 is equal to flag2"
                   .else
                   .echo   "flag1 is not equal to flag2"
                   .endif

.ENDIF
End of conditional assembly block.
The end of the conditional assembly block started by the
.IF directive is marked with this directive.  Failure to
mark the end with an .ENDIF could have some hurrendous
results on your binary code.
Examples:
   flag1           =       32
   flag2           =       4*8
                   .if     flag1 = flag2
                   .echo   "flag1 is equal to flag2"
                   .endif
   flag1           =       32
   flag2           =       4*8
                   .if     flag1 = flag2
                   .echo   "flag1 is equal to flag2"
                   .else
                   .echo   "flag1 is not equal to flag2"
                   .endif

.IFDEF
If defined conditional assembly.
Checks to see whether the constant was defined in the
source code.  If the constant was defined X816 will
continue assembling up to and .ELSE or .ENDIF.  If the
constant was not defined X816 will look for an .ELSE or
.ENDIF.

.IFNDEF
If not defined conditional assembly.
This is the opposite of the .IFDEF.  It checks whether or
not a constant was not defined.  It the constant was not
defined then X816 will continue to assemble up to an .ELSE
or .ENDIF.  If the constant was defined with X816 will
continue at an .ELSE or look for the .ENDIF.

.MACRO
Define a macro.
The macro directive sets up a block of repetitive code that
has only minor changes such as different values.  Once a
macro has been defined the source code within that macro
can be inserted at any point in the source simply by using
the macro name preceded with a period (.) as an operator.
Parameters to be passed in a macro must be enclosed with
parenthesis and each parameter separated by a comma.  Up to
32 parameters may be passed to a macro.
Example:
                   .org    $8000
   storetext       .macro  (TEXT)
                   jmp     +
                   .dcb    "TEXT",0
   +
                   .endm
                   .storetext ("Minus-Media")
                   rts

     1 008000                              .ORG   $8000
     2 008000 [macro]     STORETEXT        .MACRO (TEXT)
     3 008000 [macro]                      JMP    +
     4 008000 [macro]                      .DCB   "TEXT",0
     5 008000 [macro]     +
     6 008000                              .ENDM
     7 008000                              .STORETEXT ("Minus-Media")
     3 008000 4C 0F 80                     JMP    +
     4 008003 [00000C]                     .DCB   "Minus-Media",0
     5 00800F             +
     6 00800F                              .ENDM
     8 00800F 60                           RTS

You may nest upto 16 macros within one another.  The
parameter names passed in the macro should be no longer
than 31 characters.  Actual symbols can be used when
calling a macro, in which case the corresponding value
will be used.  Only the label, operator and operand fields
are scanned for any of the parameter names.

One final note to remember is that the operator field
is capitalized except for text appearing within quotes,
so make sure you use the proper casing in your macros.

.MODULE (.MOD)
Defines a new module.
All symbols preceded with a local symbol character such as
-, +, or @ are defined as local symbols.  These symbols are
only accessible within the same module they are defined.
The use of the .MODULE directive allows you to assign a new
module name, effectively clearing any previous local
symbols you may have used earlier in your source code.
Example:
                   .module xxx
                   ldx     #0
   @loop           dex
                   bne     @loop
                   rts
                   .module yyy
                   ldy     #0
   @loop           dey
                   bne     @loop
                   rts

If you try to assemble the above code no errors will occur
even though the same symbol name is used twice.  Removing
the .module yyy and reassembling will generate a duplicate
symbol error because the same symbol name was used earlier.

The default character for the local symbol character is @
but this can be changed using the .LOCALSYMBOLCHAR
directive.  If you do change the character make sure you
use a unique character.

.LOCALSYMBOLCHAR (.LOCCHAR)
Define local symbol character.
The local symbol character is the character used at the
beginning of a symbol name to signify it is only used
within the current module.  The default character is the
'@' symbol.  Be careful to choose a unique character that
will not disrupt the assembler.
Example:
                   .LOCALSYMBOLCHAR "_"
   _loop           dey
                   bne     _loop

Redefines the local symbol character as '_',
the underscore.

.ASCTABLE
Define ASC table.
Graphic tiles do not always line up with your standard
ASCII table and need to be modified manually or with an
extra routine.  This directive allows you to have X816
automatically reassign those ASC values while it is
assembling.  When you have completed all your definitions
you need to mark the end with the .END directive.

For example the letter 'A' has an ASCII value of 65 but in
your tileset the letter 'A' is assigned to tile #1.  You
could reassign the letter 'A' to 1 instead of 65.
Example:
                   .asctable
   65              =       1
                   .end

You may also set a range of values instead of doing each
character one at a time.
Example:
                   .asctable
   cleartable
   "A".."Z"        =       1
                   .end

The example above will assign letters 'A' to 'Z' with 'A'
starting at 1 and 'Z' ending at 27.

Only values from 0 to 255 are accepted.  Any other values
will generate an error.

The ASC table is cleared at the beginning of each pass and
may also be cleared at anytime during the assembling
process by using the statement CLEARTABLE or just CLEAR
while in the ASC definition mode.  This command has been
added so that the ASC table can be redefined any time in
the source code.

A seperate directive is setup to use the ASC table rather
than the standard .DCB directive.  Only the .ASC directive
will make use of the ASC table.

.ASC
Text data remapped with ASC table.
This directive is similiar to the .DCB directive with one
little change.  All bytes of data parsed in the operand
field are remapped to the corresponding value in the
ASC table, defined with the directive .ASCTABLE.  This will
allow you to automatically reorder your text to match your
tiles without having to do it manually with a series of
numbers.
Example:
                   .asctable
   "0".."9"        =       0
   "A".."Z"        =       10
                   .end
                   .asc    "HELLO"

The resulting data would be 18,15,22,22,25.

All values in the ASC table are set to 0 so if an ASC value
is not set it will be 0.

.TABLE (.TAB)
Set data table address.
This directive is similiar to the .BASE directive with only
one exception, no data is actually output between .TABLE
and .END.  The primary use for .TABLE is to quickly create
data tables or records.
Example:
                   .table  $0100
  temp1            .dcb    0
  temp2            .dcw    0,0
  temp3            .dsb    32
  temp4            .dsw    1
                   .end

In the above example temp1 would equal $100, temp2 equals
$101, temp3 equals $103 and temp4 equals $123.  The address
range from temp1 to the end of temp4 would be $100-$124.
Doing it the old way would look like this:
  temp1            =       $100
  temp2            =       temp1+1
  temp3            =       temp2+2
  temp4            =       temp3+32

You can see the advantages when you need to add in extra
space between labels.

One warning about the .TABLE directive, it uses the same
set of variable space and routines as .BASE.  The maximum
number of .BASE and .TABLE you can nest has been increased
to 32 from 16.  As well you shouldn't use a .BASE within a
.TABLE ... .END since this may knock your code out of
alignment.  It's more than likely you will not do this in
the first place.


Technical Notes
---------------
X816 is written in Turbo Pascal.
Maximum 31 characters per symbol name.
Maximum 40960 symbols.
Maximum 32768 modules.
Up to 255 if conditional directives can be nested.
Up to 16 macros can be nested.
Up to 32 parameters may be passed in a macro.
Up to 16 source includes can be nested.
Up to 32 base addresses can be nested.


Related Points of Interest
--------------------------
So you're interested in learning about the SNES or maybe
even programming on it?  Well here's a few sites that may
be of interest to you.

   http://minus.parodius.com
      Look me up at my own site.  This is where you can
      find most of my work, including new updates to
      X816!  Check it out.

   http://www.anthrox.com/
      Anybody who owns a copier knows Anthrox.  The group
      has put up their own web page with a section
      dedicated to SNES programming.  Includes source
      codes to some of their intros and trainers.


Closing Words
-------------
Look for some of these on my homepage!

        Modular Escape demo - Christmas demo with a
                jukebox that plays various songs
                converted from the MOD format.
        F4CG intro - an intro screen for the Fantastic
                Four Cracking Group that was never used.
        Titans experiment - a nifty Titans sword logo
                using the rotating function in mode 7.
        Zoomer - found in the Tricks Assembler which
                does some zooming/rotating in mode 7.

As always I'd like to see what you've made for the SNES.
Just uuencode to me a copy of your final product or catch
me on IRC channel #emu or #mpeg3.  All work sent to me
will be kept confidential.

                                     minus@smartt.com

