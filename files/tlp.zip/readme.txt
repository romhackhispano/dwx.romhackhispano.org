TileLayerPro Version 1.1 Header Hack
by Kejardon . . . 07/17/06

TileLayerPro skips the header it thinks a file should have.
For example, a graphic file that is read in SNES 4bpp format will appear to start 
at $200 in TileLayerPro.  As the graphic file doesn't have a header though, this 
is wrong.  The result is that $200 bytes of the file have become untouchable.

This patch fixes this issue by making the scrollbar minimum remain at zero.  The 
patch must be used with TileLayerPro version 1.1 (the most recent version, I believe).

Jathys