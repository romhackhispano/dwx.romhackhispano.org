/* Script Inserter 1.0
by Griffin Knodle, a.k.a. Jair, 10/30/98
E-mail: gknodle@trinity.edu
http://fly.to/vale

TERMS OF USE

This program is distributed with its source code. You may use,
distribute, and modify it freely. Only two restrictions: These terms of use 
must stay the same, and you must always include the source code with the
program. Oh, and I'd appreciate it if you credit me as the original
author.*/

#include <stdio.h>
#include <stdlib.h>
#include "vale.h"
#include "readtbl.h"


void sortConversions();
int compare(char*, char*);
void readFile();
void convertText();
void writeFile();
int convertChar(unsigned char*);
void writeXX(unsigned char);
int countDigits(int, char*);
void writePtrTbl();

unsigned char* converted;
unsigned char* input;
int tblPtr;
char tblName[35];
unsigned char* convertFrom;
unsigned char* convertFrom2;
unsigned char* status;
unsigned char** convertTo;
int entry;
char romName[35];
long int start;
int romPtr, textPtr;
long int offset;
char textName[35];
unsigned int charCount;
int lineCount, sectLineCount;
int unconvertableMode = 1;
int appendFlag = 0;
int breakConversion = 0;
long int inputPos = 0, convertedPos = 0;
int lineLength = 10000, sectionLength = 10000, messageLength = 10000;
long int breakablePos;
int charsSinceLastBreakable;
unsigned char newLine, newSection, newMessage;
unsigned char newLine2, newSection2, newMessage2;
unsigned char newLineString[3], newSectionString[6], newMessageString[5];
unsigned char breakStatus;
char messageBreak[5];
int ptrPtr;
long int ptrTblOffset = -1;
int romType = -1;


void main(){
  int c;

  tblinput:  // open table file
  printf("Table file:");
  getString(30, tblName);
  if(tblName[0] == 0) goto tblinput;
  addExt(tblName, "tbl");
  tblPtr = openFile(tblName, 'r');
  if(tblPtr == -1){
    printf("Couldn't open %s.\n\n", tblName);
    goto tblinput;
    }

  readTable();
  if(entry == 0){
    printf("%s contains no entries!\n", tblName);
    goto tblinput;
    }
  sortConversions();

  rominput: // open text file
  printf("Text file to read from:");
  getString(30, textName);
  if(textName[0] == 0){
    for(c = 0; tblName[c] != 0; c++)
      textName[c] = tblName[c];
    changeExt(textName, "txt");
    }
  addExt(textName, "txt");
  textPtr = openFile(textName, 'r');
  if(textPtr == -1){
    printf("Couldn't open %s.\n\n", textName);
    goto rominput;
    }
  readFile();
   
  printf("File to write converted text to:");
  getString(30, romName);
  if(romName[0] == 0){
    for(c = 0; textName[c] != 0; c++)
      romName[c] = textName[c];
    changeExt(romName, "nes");
    }
  addExt(romName, "nes");
  romPtr = openFile(romName, 'w');

  printf("\nAddress to start inserting at:");
  offset = hexInput();
  seek(romPtr, offset);

  if(compareExt(romName, "nes") == 0)
    romType = 0;
  if(compareExt(romName, "smc") == 0 || compareExt(romName, "fig") == 0 ||
      compareExt(romName, "sfc") == 0)
    romType = 1000;

  if(ptrTblOffset > -1){
    ptrPtr = openFile(romName, 'w');
    seek(ptrPtr, ptrTblOffset);
    }

  convertText();

  printf("\nOK to overwrite %ld bytes?", convertedPos);
  getString(1, messageBreak);
  if(messageBreak[0] != 'N' && messageBreak[0] != 'n') {
    writeFile();
    if(ptrTblOffset > -1)
      writePtrTbl();
    }
  else
    printf("\nInsertion aborted.\n");

  close(romPtr);
  close(textPtr);
  close(tblPtr);
  }

void writePtrTbl(){
  int c = 0;
  unsigned int offsetBuffer;
			   
  offsetBuffer = fileToROM(offset, romType);
  _write(ptrPtr, &offsetBuffer, 2);

  while(c < convertedPos){
    if(converted[c] == newMessage && c + 1 < convertedPos){
      offsetBuffer = fileToROM(offset + c + 1, romType);
      _write(ptrPtr, &offsetBuffer, 2);
      }
    c++;
    }
  printf("Pointer table rewritten.\n");
  }

int convertChar(unsigned char* buffer){
  int index, max, min, c, d;
  unsigned char space[2] = " ";

  if(testBit(breakStatus, 2) == 1)
    if(bCompare(buffer, newMessageString) == 0){
      converted[convertedPos] = newMessage;
      convertedPos++;
      converted = (unsigned char*) realloc(converted, sizeof(unsigned char) *
	  (convertedPos +1));
      if(testBit(breakStatus, 5) == 1) {
	converted[convertedPos] = newMessage2;
	convertedPos++;
	converted = (unsigned char*) realloc(converted, sizeof(unsigned char) *
	    (convertedPos + 1));
	}
      lineCount = 0;
      sectLineCount = 0;
      charCount = 0;
      breakablePos = convertedPos - 1;
      for(c = 0; newMessageString[c] != 0; c++)
	inputPos++;
      goto tests;
      }
  if(testBit(breakStatus, 1) == 1)
    if(bCompare(buffer, newSectionString) == 0){
      converted[convertedPos] = newSection;
      convertedPos++;
      converted = (unsigned char*) realloc(converted, sizeof(unsigned char) *
	  (convertedPos +1));
      if(testBit(breakStatus, 4) == 1) {
	converted[convertedPos] = newSection2;
	convertedPos++;
	converted = (unsigned char*) realloc(converted, sizeof(unsigned char) *
	    (convertedPos + 1));
	}
      charCount = 0;
      sectLineCount = 0;
      breakablePos = convertedPos - 1;
      for(c = 0; newSectionString[c] != 0; c++)
	inputPos++;
      goto tests;
      }
  if(testBit(breakStatus, 0) == 1)
    if(bCompare(buffer, newLineString) == 0){
      converted[convertedPos] = newLine;
      convertedPos++;
      converted = (unsigned char*) realloc(converted, sizeof(unsigned char) *
	  (convertedPos +1));
      if(testBit(breakStatus, 3) == 1) {
	converted[convertedPos] = newLine2;
	convertedPos++;
	converted = (unsigned char*) realloc(converted, sizeof(unsigned char) *
	    (convertedPos + 1));
	}
      charCount = 0;
      breakablePos = convertedPos - 1;
      lineCount++;
      sectLineCount++;
      for(c = 0; newLineString[c] != 0; c++)
	inputPos++;
      goto tests;
      }

  if(buffer[0] < convertTo[0][0] || buffer[0] > convertTo[entry - 1][0])
    goto noMatch;
  if(buffer[0] == convertTo[0][0]) {
    index = 0;
    goto foundMatch;
    }
  if(buffer[0] == convertTo[entry - 1][0]) {
    index = entry - 1;
    goto foundMatch;
    }
  min = 0;
  max = entry - 1;
  index = (min + max) / 2;

  while (buffer[0] != convertTo[index][0] && min <= max){
  if(buffer[0] < convertTo[index][0]){
    max = index - 1;
    index = (min + max) / 2;
    }
  else{
    min = index + 1;
    index = (min + max) / 2;
    }
  }

  if(min > max) {
    noMatch:
    return 1;
    }
  foundMatch:
  while(index > 0 && convertTo[index - 1][0] == convertTo[index][0])
    index--; // seek to first entry starting with this character
  while(index < entry && testBit(status[index], 0) == 0){
    index++; // don't pick values that aren't regular conversion values
    if(convertTo[index][0] != convertTo[index - 1][0])
      break;
    }
  if(convertTo[index][0] != buffer[0])
    goto noMatch; // all the matches were something else -- e.g. prog cont chars
  while(1){
    if(index == entry)
      break; // no matches
    if(convertTo[index][0] != buffer[0])
      break; // no matches
    c = 0;
    while(convertTo[index][c] != 0){
      if(convertTo[index][c] != buffer[c])
	break; // buffer doesn't match
      c++;
      }
    if(convertTo[index][c] == 0)
      break; // found a match
    index++;
    }
  if(index == entry)
    goto noMatch;
  if(convertTo[index][0] != buffer[0])
    goto noMatch; // this can happen when all the conversions are > 1 byte long

  if(compare(convertTo[index], space) == 0){
    breakablePos = convertedPos;
    charsSinceLastBreakable = 0;
    }
  converted[convertedPos] = convertFrom[index];
  convertedPos++;
  converted = (char*) realloc(converted, sizeof(char) * (convertedPos + 1));
  if(testBit(status[index], 7) == 1) { // two-byte conversion
    converted[convertedPos] = convertFrom2[index];
    convertedPos++;
    converted = (char*) realloc(converted, sizeof(char) * (convertedPos + 1));
    }
  for(c = 0; convertTo[index][c] != 0; c++){
    inputPos++;
    charCount++;
    charsSinceLastBreakable++;
    }
  tests:
  if(charCount > lineLength) {
    if(lineLength < 10000) {
      if(breakablePos > -1) {
	converted[breakablePos] = newLine;
	charCount = charsSinceLastBreakable - 1; // - 1 b/c the count includes space
	lineCount++;
        sectLineCount++;
	}
      }
    }
  if(sectLineCount == sectionLength){
    if(sectionLength < 10000){
      converted[breakablePos] = newSection;
      sectLineCount = 0;
      }
    }
  if(lineCount == messageLength){
    if(messageLength < 10000){
      converted[breakablePos] = newMessage;
      convertedPos = breakablePos + 1; // reset cPos to right after message end
      printf("Warning: \"");
      for(c = 2 - charsSinceLastBreakable; buffer[c] != 0; c++) {
	for(d = 0; messageBreak[d] != 0; d++) {
	  if(buffer[c + d] != messageBreak[d]) break;
	  }
	if(messageBreak[d] == 0) break;
	printf("%c", buffer[c]);
	}
      printf("\"\n  overruns message length limit and will not be inserted.\n");
      charCount = 0;
      lineCount = 0;
      while(input[inputPos] != 0){
	for(d = 0; messageBreak[d] != 0; d++){
	  if(input[inputPos + d] != messageBreak[d]) break;
	  }
	if(messageBreak[d] == 0) break;
        inputPos++;
	}
      for(d = 0; messageBreak[d] != 0; d++){
	inputPos++; // set inputPos to the start of the next message
        }
      }
    }
  if(converted[breakablePos] == newLine || converted[breakablePos] == newSection ||
      converted[breakablePos] == newMessage)
    breakablePos = -1;
  if(breakablePos == -1)
    charsSinceLastBreakable = 0;
  return 0;
  }

void convertText(){
  int c, d;
  unsigned int offsetBuffer;

  charCount = 0;
  lineCount = 0;
  breakablePos = -1;
  charsSinceLastBreakable = 0;

  while(input[inputPos] != 0) {
    if(convertChar(&input[inputPos]) == 1){
      if(input[inputPos] == '<'){
	for(c = 0; c < entry; c++){
	  if(testBit(status[c], 1) == 0) // not a program cont char
	    continue;
	  for(d = 0; convertTo[c][d] != 0; d++){
	    if(input[inputPos + d + 1] != convertTo[c][d])
	      break; // doesn't match
	    }
	  if(convertTo[c][d] == 0)
	    break; // found a match at convertTo[c]
	  }
	if(c < entry) { // found a match
	  if(readXX(&input[inputPos + d + 2], 2) > 0 || input[inputPos + d + 2] ==
	      '0'){  // real match
	    if(input[inputPos + d + 4] == '>'){ // yup, complete match
	      converted = (char*) realloc(converted, sizeof(char) *
		  (convertedPos + 3));
	      converted[convertedPos] = convertFrom[c];
	      converted[convertedPos + 1] = readXX(&input[inputPos + d + 2], 2);
	      convertedPos += 2;
	      inputPos += (d + 5);
	      }
	    else {
	      printf("Warning: cannot convert \"<\"\n");
	      inputPos++;
	      }
	    }
	  else {
	    printf("Warning: cannot convert \"<\"\n");
	    inputPos++;
	    }
	  }
	else {  // <xx> (hopefully)
	  if(readXX(&input[inputPos + 1], 2) > 0 || input[inputPos + 1] == '0'){
	    converted[convertedPos] = readXX(&input[inputPos + 1], 2);
	    convertedPos++;
            inputPos += 4;
	    converted = (char*) realloc(converted, sizeof(char) * (convertedPos + 1));
	    }
	  else {
	    printf("Warning: cannot convert \"<\"\n");
	    inputPos++;
	    }
	  }
	}
      else{
        printf("Warning: cannot convert \"%c\"\n", input[inputPos]);
        inputPos++;
	}
      }
    }
  converted[convertedPos] = 0;
  }

void writeFile(){
  int c = 0;

  while(c < convertedPos){
    _write(romPtr, &converted[c], 1);
    c++;
    }
  printf("\n%d bytes overwritten.\n", c);
  }

void readFile(){
  int c = 0;

  converted = (char*) malloc(sizeof(unsigned char));
  input = (char*) malloc(sizeof(unsigned char));
  while(_read(textPtr, &input[c], 1) == 1){
    c++;
    input = (char*) realloc(input, sizeof(unsigned char) * (c + 1));
    }
  input[c] = 0;
  /*for(c = 0; input[c] != 0; c++)
    printf("%c", input[c]);*/
  }

void sortConversions(){
  int c, d, e;
  unsigned char tempInt, tempInt2;
  unsigned char* tempChar;
  int tempStatus;
		   
  if(testBit(breakStatus, 0) == 1){
    if(breakConversion == 0){
      newLineString[0] = 0x0d;
      newLineString[1] = 0x0a;
      newLineString[2] = 0;
      }
    else{
      breakStatus -= 1; // don't try to convert ' ' to a line break!
      }
    }
  if(testBit(breakStatus, 1) == 1){
    if(breakConversion < 2){
      newSectionString[0] = 0x0d;
      newSectionString[1] = 0x0a;
      newSectionString[2] = 92;
      newSectionString[3] = 0x0d;
      newSectionString[4] = 0x0a;
      newSectionString[5] = 0;
      }
    else{
      newSectionString[0] = 92;
      newSectionString[1] = 0;
      }
    }
  if(testBit(breakStatus, 2) == 1){
    if(breakConversion < 2){
      newMessageString[0] = 0x0d;
      newMessageString[1] = 0x0a;
      newMessageString[2] = 0x0d;
      newMessageString[3] = 0x0a;
      newMessageString[4] = 0;
      }
    else{
      newMessageString[0] = 0x0d;
      newMessageString[1] = 0x0a;
      newMessageString[2] = 0;
      }
    }
  if(entry == 1) return;
  for(c = 0; c < entry - 1; c++){ // insertion sort
    if(compare(convertTo[c + 1], convertTo[c]) > 0)
      continue;

    tempInt = convertFrom[c + 1];          
    tempInt2 = convertFrom2[c + 1];
    tempChar = &convertTo[c + 1][0]; // we're sorting pointers; the strings don't move
    tempStatus = status[c + 1];

    d = c + 1;
    while (1){
      if(compare(tempChar, convertTo[d - 1]) > 0)
	break;
      convertFrom[d] = convertFrom[d - 1]; 
      convertFrom2[d] = convertFrom2[d - 1];
      convertTo[d] = &convertTo[d - 1][0];
      status[d] = status[d - 1];
      d--;
      if(d == 0)
        break;
      }

    convertFrom[d] = tempInt; 
    convertFrom2[d] = tempInt2;
    convertTo[d] = &tempChar[0];
    status[d] = tempStatus;
    }
  /*for(c = 0; c < entry; c++){
    printf("%X", convertFrom[c]);
    if(testBit(status[c], 7) == 1)
      printf(" %X", convertFrom2[c]);
    printf("=%d/%d ", convertTo[c][0], convertTo[c][1]);
    }*/
  }

void writeXX(unsigned char buffer){
  char temp;

  if(buffer / 16 > 9)
    temp = buffer / 16 + 'A' - 10;
  else
    temp = buffer / 16 + '0'; 
  _write(textPtr, &temp, 1);
  if(buffer % 16 > 9)
    temp = buffer % 16 + 'A' - 10;
  else
    temp = buffer % 16 + '0';
  _write(textPtr, &temp, 1);
  }

int countDigits(int index, char* buffer){
  int c;

  c = 0;
  while(hex(buffer[index + c]) > 0 || buffer[index + c] == '0')
    c++;
  return c;
  }
