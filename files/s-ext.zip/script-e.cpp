/* Script Extractor 1.3
by Griffin Knodle, a.k.a. Jair, 10/30/98
E-mail:gknodle@trinity.edu
http://fly.to/vale

TERMS OF USE
-------------------
This program is distributed with its source code.  You may use, distribute, and modify
it freely.  Only two restrictions: These terms of use must stay the same, and you must
always include the source code with the program.  Oh, and I'd appreciate it if you
credit me as the original author.*/

#include <stdio.h>
#include <stdlib.h>
#include "vale.h"
#include "readtbl.h"


void sortConversions();
void convertText();
int convertChar(unsigned char*);
void writeXX(unsigned char);
int countDigits(int, char*);

int tblPtr;
char tblName[35];
unsigned char* convertFrom;
unsigned char* convertFrom2;
unsigned char* status;
unsigned char** convertTo;
int entry;
char romName[35];
long int start;
int romPtr, textPtr;
long int offset;
char textName[35];
long int byteCount;
unsigned int charsWritten;
int sectionsWritten;
int messagesWritten;
int unconvertableMode = 1;
int appendFlag = 0;
int breakConversion = 0;
int lastByteFlag = 0;
unsigned char newLine, newSection, newMessage;
unsigned char newLine2, newSection2, newMessage2;
unsigned char breakStatus = 0; // bit 0 = line break present; 1=sect; 2=msg
unsigned char newLineString[3], newSectionString[6], newMessageString[5];

int lineLength, sectionLength, messageLength; // only used by SE, but needed by
long int ptrTblOffset; // readtbl.h


void main(){
  int c;

  tblinput:  // open table file
  printf("Table file:");
  getString(30, tblName);
  if(tblName[0] == 0) goto tblinput;
  addExt(tblName, "tbl");
  tblPtr = openFile(tblName, 'r');
  if(tblPtr == -1){
    printf("Couldn't open %s.\n\n", tblName);
    goto tblinput;
    }

  readTable();
  if(entry == 0){
    printf("%s contains no entries!\n", tblName);
    goto tblinput;
    }
  sortConversions();

  rominput: // open ROM
  printf("File to extract text from:");
  getString(30, romName);
  if(romName[0] == 0){
    for(c = 0; tblName[c] != 0; c++)
      romName[c] = tblName[c];
    changeExt(romName, "nes");
    }
  addExt(romName, "nes");
  romPtr = openFile(romName, 'r');
  if(romPtr == -1){
    printf("Couldn't open %s.\n\n", romName);
    goto rominput;
    }
   
  printf("File to write to:");
  getString(30, textName);
  if(textName[0] == 0)
    for(c = 0; romName[c] != 0; c++)
      textName[c] = romName[c];
  changeExt(textName, "txt");
  if(appendFlag == 0)
    textPtr = openFile(textName, 't');
  else
    textPtr = openFile(textName, 'w');
  lseek(textPtr, 0, SEEK_END);
  charsWritten = 0;
  sectionsWritten = 1;
  messagesWritten = 1;

  printf("\nText block's starting address:");
  offset = hexInput();
  lseek(romPtr, offset, 0);
  printf("Number of bytes to extract:");
  byteCount = hexInput();

  convertText();

  printf("\nScript successfully extracted to %s.\n", textName);
  printf("  � %u character(s)\n", charsWritten);
  printf("  � %d section(s)\n  � %d message(s)", sectionsWritten, messagesWritten);

  close(textPtr);
  close(tblPtr);
  close(romPtr);
  }

int convertChar(unsigned char* buffer){
  int index, max, min;
  char* tempPtr = NULL;
  int twoByteBreakFlag = 0;

  if(testBit(breakStatus, 0) == 1)
    if(buffer[0] == newLine) {
      if(testBit(breakStatus, 3) == 1) {
	if(buffer[1] == newLine2) {
	  tempPtr = &newLineString[0];
	  twoByteBreakFlag = 1;
	  }
	}
      else
	tempPtr = &newLineString[0];
      }
  if(testBit(breakStatus, 1) == 1)
    if(buffer[0] == newSection) {
      if(testBit(breakStatus, 4) == 1) {
	if(buffer[1] == newSection2) {
	  tempPtr = &newSectionString[0];
	  twoByteBreakFlag = 1;
          sectionsWritten++;
	  }
	}
      else {
	tempPtr = &newSectionString[0];
	sectionsWritten++;
        }
      }
  if(testBit(breakStatus, 2) == 1)
    if(buffer[0] == newMessage) {
      if(testBit(breakStatus, 5) == 1) {
	if(buffer[1] == newMessage2) {
	  tempPtr = &newMessageString[0];
	  twoByteBreakFlag = 1;
          sectionsWritten++;
          messagesWritten++;
	  }
	}
      else {
        tempPtr = &newMessageString[0];
        sectionsWritten++;
	messagesWritten++;
        }
      }
  if(tempPtr != NULL){
    if(twoByteBreakFlag == 1){
      if(lastByteFlag == 1)
        return 1;
      buffer[0] = buffer[1];
      _read(romPtr, &buffer[1], 1);
      byteCount--;
      }
    for(index = 0; tempPtr[index] != 0; index++){
      _write(textPtr, &tempPtr[index], 1);
      }
    return 0;
    }
    
  if(buffer[0] < convertFrom[0] || buffer[0] > convertFrom[entry - 1])
    return 1;
  if(buffer[0] == convertFrom[0]) {
    index = 0;
    goto foundMatch;
    }
  if(buffer[0] == convertFrom[entry - 1]) {
    index = entry - 1;
    goto foundMatch;
    }
  min = 0;
  max = entry - 1;
  index = (min + max) / 2;
  while (buffer[0] != convertFrom[index] && min <= max){
    if(buffer[0] < convertFrom[index]){
  max = index - 1;
    index = (min + max) / 2;
    }
  else{
    min = index + 1;
    index = (min + max) / 2;
    }
  }
  if(min > max) return 1;
  foundMatch:
  while(index > 0 && convertFrom[index - 1] == convertFrom[index])
    index--;
  while(1){
    if(index + 1 == entry) // comparing last entry
      break;
    if(convertFrom[index + 1] != buffer[0]) // comparing last first-byte-match
      break;
    if(testBit(status[index], 7) == 1) { // two-byte conversion
      if(convertFrom2[index] == buffer[1] && lastByteFlag == 0) // two-byte match
	break;
      }
    else // no more two-byte conversions -- we're done comparing
      break;
    index++;
    }    
  min = 0;
  if(testBit(status[index], 0) == 1){
    while(convertTo[index][min] != 0){
      _write(textPtr, &convertTo[index][min], 1);
      charsWritten++;
      min++;
      }
    }

  if(testBit(status[index], 1) == 1) { // trigger for control char printout
    if(lastByteFlag == 1)
      return 1;
    _write(textPtr, "<", 1);
    min = 0;
    while(convertTo[index][min] != 0){
      _write(textPtr, &convertTo[index][min], 1);
      min++;
      }
    _write(textPtr, " ", 1);
    buffer[0] = buffer[1];
    _read(romPtr, &buffer[1], 1);
    byteCount --;
    writeXX(buffer[0]);
    _write(textPtr, ">", 1);
    }

  if(testBit(status[index], 7) == 1) { // two-byte conversion
    if(lastByteFlag == 1)
      return 1;
    buffer[0] = buffer[1];
    _read(romPtr, &buffer[1], 1);
    byteCount--;
    }

  if(convertTo[index][0] == 164 || convertTo[index][0] == 165 || convertTo[index]
      [0] == 161)
    charsWritten--;
  return 0;
  }

void convertText(){
  unsigned char buffer[2];

  if(_read(romPtr, buffer, 1) == 1)
  while(_read(romPtr, &buffer[1], 1) == 1) {
    byteCount --;
    if(byteCount < 1) break;
    if(convertChar(buffer) == 1){ // unconvertable byte
      switch(unconvertableMode){
	case 1: // <xx>
	  _write(textPtr, "<", 1);
	  writeXX(buffer[0]);
	  _write(textPtr, ">", 1);
	  break;
	case 2: // ASCII char
	  _write(textPtr, &buffer[0], 1);
	  break;
	}
      }
    buffer[0] = buffer[1];
    }
  lastByteFlag = 1;
  if(convertChar(buffer) == 1){ // unconvertable byte
    switch(unconvertableMode){
      case 1: // <xx>
        _write(textPtr, "<", 1);
	writeXX(buffer[0]);
	_write(textPtr, ">", 1);
	break;
      case 2: // ASCII char
        _write(textPtr, &buffer[0], 1);
        break;
      }
    }
  }

void sortConversions(){
  int c, d, e;
  unsigned char tempInt, tempInt2;
  char* tempChar;
  int tempStatus;
		   
  if(testBit(breakStatus, 0) == 1){
    if(breakConversion == 0){
      newLineString[0] = 0x0d;
      newLineString[1] = 0x0a;
      newLineString[2] = 0;
      }
    else{     
      newLineString[0] = ' ';
      newLineString[1] = 0;
      }
    }
  if(testBit(breakStatus, 1) == 1){
    if(breakConversion < 2){
      newSectionString[0] = 0x0d;
      newSectionString[1] = 0x0a;
      newSectionString[2] = 92;
      newSectionString[3] = 0x0d;
      newSectionString[4] = 0x0a;
      newSectionString[5] = 0;
      }
    else{
      newSectionString[0] = 92;
      newSectionString[1] = 0;
      }
    }
  if(testBit(breakStatus, 2) == 1){
    if(breakConversion < 2){
      newMessageString[0] = 0x0d;
      newMessageString[1] = 0x0a;
      newMessageString[2] = 0x0d;
      newMessageString[3] = 0x0a;
      newMessageString[4] = 0;
      }
    else{
      newMessageString[0] = 0x0d;
      newMessageString[1] = 0x0a;
      newMessageString[2] = 0;
      }
    }
  if(entry == 1) return;
  for(c = 0; c < entry - 1; c++){ // insertion sort
    if(convertFrom[c + 1] > convertFrom[c])
      continue;
    if(convertFrom[c + 1] == convertFrom[c]){
      if(status[c + 1] < status[c])
	continue;
      if(testBit(status[c + 1], 7) == 1 && testBit(status[c], 7) == 1)
	if(convertFrom2[c + 1] > convertFrom2[c])
	  continue;
      }        

    tempInt = convertFrom[c + 1];          
    tempInt2 = convertFrom2[c + 1];
    tempChar = &convertTo[c + 1][0];
    tempStatus = status[c + 1];

    d = c + 1;
    while (1){
      if(tempInt > convertFrom[d - 1])
        break;
      if(tempInt == convertFrom[d - 1]){
        if(tempStatus < status[d - 1])
	  break;
	if(testBit(tempStatus, 7) == 1 && testBit(status[d - 1], 7) == 1)
	  if(tempInt2 > convertFrom2[d - 1])
	    break;
	}
      convertFrom[d] = convertFrom[d - 1]; 
      convertFrom2[d] = convertFrom2[d - 1];
      convertTo[d] = &convertTo[d - 1][0];
      status[d] = status[d - 1];
      d--;
      if(d == 0)
        break;
      }

    convertFrom[d] = tempInt; 
    convertFrom2[d] = tempInt2;
    convertTo[d] = &tempChar[0];
    status[d] = tempStatus;
    }
  /*for(c = 0; c < entry; c++){
    printf("%X", convertFrom[c]);
    if(testBit(status[c], 7) == 1)
      printf(" %X", convertFrom2[c]);
    printf("=%s\n", convertTo[c]);
    }*/
  }

void writeXX(unsigned char buffer){
  char temp;

  if(buffer / 16 > 9)
    temp = buffer / 16 + 'A' - 10;
  else
    temp = buffer / 16 + '0'; 
  _write(textPtr, &temp, 1);
  if(buffer % 16 > 9)
    temp = buffer % 16 + 'A' - 10;
  else
    temp = buffer % 16 + '0';
  _write(textPtr, &temp, 1);
  }

int countDigits(int index, char* buffer){
  int c;

  c = 0;
  while(hex(buffer[index + c]) > 0 || buffer[index + c] == '0')
    c++;
  return c;
  }
