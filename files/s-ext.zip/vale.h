/* Vale Header v.5.1
by Griffin Knodle, a.k.a. Jair, 10/30/98
E-mail: gknodle@trinity.edu
http://fly.to/vale

CONTENTS

int bCompare(unsigned char* firstString, unsigned char* secondString)
   - like compare, but returns 0 (match) if one string is longer but the beginning
     matches the other string.

void seek(int fileHandle, long int offset)
   - kind of like lseek, but will add blank space to the end of the file if you're
     trying to seek past the current end of the file.

int compareExt(unsigned char* string, unsigned char* extension)
   - same as compare, but only checks the characters after the period in string.

unsigned int fileToROM(long int fileOffset, int mode)
   - converts an ordinary file offset to memory offset (as it appears in the ROM).
     mode is a switch for ROM type.  See comments in function for details.

int seekChar(char* originalPointer, char charToSeekTo)
   - Returns the number of chars to seek over before the given character appears.

int seekPastSpaces(char* originalPointer)
   - Returns the number of spaces to seek over before the next non-space character.

int readDD(char* charsToConvert, int howManyCharsToConvert)
   - Converts from an ASCII decimal string to an integer.

int compare(unsigned char* firstString, unsigned char* secondString)
   - Compares the two strings.  Returns 0 if they are equal.  Returns the value of
     firstString[x] - secondString[x] if there's a difference.  However, it will
     return negative if secondString is shorter than firstString, and vice versa.

long int readXX(char* charsToConvert, int howManyCharsToConvert)
   - Converts the characters from hex ASCII to an integer value.

int testBit(unsigned char valueToTest, int bitToTest)
   - Tests the specified bit in valueToTest (0-7).  Returns 1 if bit is set, 0 if not.

int hex(char digitToConvert)
   - Returns between 0 and 15, converting from 0-9 and A-F.  Returns 0 on failure.

void addExt(char* stringToModify, char* extensionToAdd)
   - Takes a string and adds .extensionToAdd if it doesn't have an extension yet.

void changeExt(char* stringToModify, char* extensionToAdd)
   - Takes a string and changes its .extension to .extensionToAdd.

int openFile(char* nameOfFileToOpen, char openingMode)
   - Opens a file. Returns the handle for the int.
   - values for openingMode:
      - 'w' will create the file if it doesn't exist
      - 'r' won't create it and will return -1
      - 't' acts like 'w'and erases the file's previous contents if it already exists

void getString(int stringLength, char* stringToWriteTo)
   - Will only accept a given number of characters.

long int hexInput()
   - Function used in Relative Searcher, Graphics Extractor, etc. to allow decimal
     or hexadecimal input.


TERMS OF USE

This header file is distributed for your information and use.  You may use,
distribute, and modify it freely.  You may use any or all of these functions in your
own programs if you wish.  There are only two restrictions: These terms of use 
must stay the same, and you must always include the complete source code with the
program.  Oh, and I'd appreciate it if you credit me as the original author.*/

#include <stdio.h>
#include <conio.h>
#include <io.h>
#include <fcntl.h>

int hex(char);
/*********************/

int bCompare(unsigned char* one, unsigned char* two){
  int c;

  c = 0;
  while(one[c] != 0 && two[c] != 0){
    if(one[c] != two[c])
      return one[c] - two[c];
    c++;
    }
  return 0;
  }

void seek(int fileHandle, long int offset){
  char blank = 0;
  
  if(lseek(fileHandle, 0, SEEK_END) < offset)
    printf("\nAdding space to end of file ... please wait.\n\n");
  while(lseek(fileHandle, 0, SEEK_END) < offset)
    _write(fileHandle, &blank, 1);
  lseek(fileHandle, offset, 0);
  }

int compareExt(unsigned char* string, unsigned char* ext){
  int c = 0, d = 0;

  while(string[c] != 0)
    c++; // seek to end of string
  d = c - 1;
  while(string[d] != '.'){
    d--; // seek to period
    if(d == -1) break;
    } 
  d++; // seek to char after period
  if(d == 0)
    d = c; // if no extension, seek to \0 at end
  c = 0;
  while(ext[c] == string[d + c]){
    if(ext[c] == 0) break;
    c++;
    }
  return string[d + c] - ext[c];
  }

unsigned int fileToROM(long int offset, int mode){
  switch(mode){
    case 1000: // SNES -- this is very jury-rigged
      // 1000: convert to 32K block from 8000-FFFF
      offset -= 512; // hope there's a header
      offset = offset % 0x8000;
      offset += 0x8000;
      break;
    case 0: // NES -- this is even more jury-rigged
      // 0: 16K from 8000-bfff
      offset -= 16;
      offset = offset % 0x4000;
      offset += 0x8000;
      break;
    }
  return offset;
  }

int seekChar(char* original, char target){
  int c = 0;

  while(original[c] != 0 && original[c] != target){
    c++;
    }
  return c;
  }

int seekPastSpace(char* original){
  int c = 0;

  while(original[c] == ' '){
    c++;
    }
  return c;
  }

int readDD(char* buffer, int howMany){
  unsigned int result = 0;
  int c = 0;

  while(buffer[c] >= '0' && buffer[c] <= '9'){
    result = result * 10 + (buffer[c] - '0');
    c++;
    if(c == howMany) break;
    }
  return result;
  }

int compare(unsigned char* plus, unsigned char* subtract){
  int c = 0;

  while(plus[c] == subtract[c]){
    if(plus[c] == 0)
      return 0;
    c++;
    }
  if(plus[c] == 0 || subtract[c] == 0)
    return subtract[c] - plus[c];
  return plus[c] - subtract[c];
  }

long int readXX(char* buffer, int howMany){
  long int x;
  int c;

  x = 0;
  for(c = 0; c < howMany; c++) {
    if(hex(buffer[c]) > 0 || buffer[c] == '0')
      x = x * 16 + hex(buffer[c]);
    else break;
    }
  return x;
  }

int testBit(unsigned char test, int bit){
  while(bit > 0){
    test /= 2;
    bit--;
    }
  return test % 2;
  }

int hex(char hex){
  if(hex >= '0' && hex <= '9')
    return hex - 48;
  if(hex >= 'A' && hex <= 'F')
    return hex - 55;
  if(hex >= 'a' && hex <= 'f')
    return hex - 87;
  return 0;
  }

void addExt(char* target, char* ext){
  int c = 0, d = 0, end;

  while(target[c] != 0)
    c++;
  end = c;

  while(target[c] != '.'){
    c--;
    if(c == -1) break;
    }
  if(c > -1)
    return;

  c = end;
  target[c] = '.';

  while(ext[d] != 0){
    c++;
    target[c] = ext[d];
    d++;
    }
  target[c + 1] = 0;
  }

void changeExt(char* target, char* ext){
  int c = 0, d = 0, end;

  while(target[c] != 0)
    c++;
  end = c;

  while(target[c] != '.'){
    c--;
    if(c == -1) break;
    }
  if(c == -1){
    c = end;
    target[c] = '.';
    }

  while(ext[d] != 0){
    c++;
    target[c] = ext[d];
    d++;
    }
  target[c + 1] = 0;
  }

int openFile(char* fileName, char mode){
  int filePtr;
  FILE* temp;

  if(mode == 't') filePtr = open(fileName, O_RDWR | O_TRUNC);
  else filePtr = open(fileName, O_RDWR);

  if(filePtr== -1){ // unsuccessful
    if(mode=='r'){
      return -1;
      }

    temp=fopen(fileName, "w");
    fclose(temp);
    filePtr=open(fileName, O_RDWR);
    }
  return filePtr;
  }

void getString(int length, char* target){
  int counter;
  char input;
  // Note: your string must be one char longer than "length", to leave room for
  // the '\0' end-of-string marker.

  for(counter=0; ; counter++){
    input=getch();
    if(input==13){ // enter
      printf("\n");
      break; // Note: no protection against 0-length entries
      }
    if(input==8){ //backspace
      if(counter==0){ // no input yet
	counter--;
	continue;
        }
      printf("%c",8);
      counter -= 2;
      continue;
      }
    if(counter==length){ // at max length
      counter--;
      continue;
      }
    target[counter]=input;
    printf("%c",input);
    }
  target[counter]=0;
  }

long int hexInput(){
  long int value=0;
  char hexFlag=0;
  char negFlag=0;
  char input[10];
  int charsRead=0;
  int x;

  for(charsRead=0; charsRead < 10; charsRead++){

  input[charsRead]=getch();

  if(input[charsRead]==13 && charsRead > 0){
    printf("\n");
    break; // enter
    }

  if(input[charsRead]==8){ //backspace
    charsRead--;
    if(charsRead==-1 && negFlag==1){
      negFlag=0;
      printf("%c",8);
      }
    if(charsRead==-1) continue; //not if nothing to erase
    if(hexFlag==1) hexFlag=0; // erase H
    else{ // or erase last digit
      charsRead--;
      }
    printf("%c",8);
    continue;
    }
     
  if(hexFlag==1){ // after typing H, only backspace or enter
    charsRead--;
    continue;
    }

  if(input[charsRead]=='h' || input[charsRead]=='H'){  // set H
    charsRead--;
    if(charsRead==-1) continue; // not if no value yet
    hexFlag=1;
    printf("h");
    continue;
    }
  if(input[charsRead]=='-'){ // set neg
    charsRead--;
    if(charsRead > -1) continue; // only at start
    if(negFlag==1) continue; // once is enough
    negFlag=1;
    printf("-");
    continue;
    }
  if(input[charsRead] > 96 && input[charsRead] < 103)
    input[charsRead] -= 32; // a-f -> A-F
  if(input[charsRead] > 64 && input[charsRead] < 71){
    printf("%c",input[charsRead]);
    continue;
    }
  if(input[charsRead] > 47 && input[charsRead] < 58){
    printf("%c",input[charsRead]);
    continue;
    }
  charsRead--;
  }

  if(hexFlag==0){
    for(x=0; x<charsRead; x++){
      if(input[x] > 64 && input[x] < 71){
	hexFlag=1;
	break;
	}
      }
    }

  for(x=0; x < charsRead; x++){ 
    if(hexFlag==1) value *= 16;
    else value *= 10;
    if(input[x] > 47 && input[x] < 58){// digit 0-9
      value += (input[x] - 48);
      }
    if(input[x] > 64 && input[x] < 71){ // hex digit A-F
      value += (input[x] - 55);
      }
    }

  if(negFlag==1) value = (-value);

  //printf("\n%li",value);
  return value;
  }