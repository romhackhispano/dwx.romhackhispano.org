/* readtbl.h 1.1
by Griffin Knodle, a.k.a. Jair, 10/30/98
E-mail:gknodle@trinity.edu
http://fly.to/vale

This is just my table-reading function for Script Extractor / Inserter.  I put it in
a separate file so I can change the table function in both programs at once.

TERMS OF USE
-------------------
This program is distributed with its source code.  You may use, distribute, and modify
it freely.  Only two restrictions: These terms of use must stay the same, and you must
always include the source code with the program.  Oh, and I'd appreciate it if you
credit me as the original author.*/

#include <stdio.h>
#include <stdlib.h>

extern unsigned char* convertFrom;
extern unsigned char* convertFrom2;
extern unsigned char* status;
extern unsigned char** convertTo;
extern int entry;
extern int tblPtr;
extern int unconvertableMode;
extern int appendFlag;
extern int breakConversion;
extern int lineLength, sectionLength, messageLength;
extern unsigned char newLine, newSection, newMessage;
extern unsigned char newLine2, newSection2, newMessage2;
extern unsigned char breakStatus;
extern long int ptrTblOffset;


void readTable(){
  unsigned char* buffer;
  int bufferSize;
  int c, d;
  int errorFlag = 0;

  buffer = (unsigned char*) malloc(sizeof(char));
  bufferSize = 1;
  convertFrom = (unsigned char*) malloc(sizeof(unsigned char)); // init table data
  convertFrom2 = (unsigned char*) malloc(sizeof(unsigned char));
  status = (unsigned char*) malloc(sizeof(unsigned char));
  status[0] = 0;
  convertTo = (unsigned char**) malloc(sizeof(char*));
  convertTo[0] = (unsigned char*) malloc(sizeof(char));
  entry = 0;

  newLine:
  c = 0;
  do{
    if(c == bufferSize){ // need to increase buffer size
      bufferSize++;
      buffer = (unsigned char*) realloc(buffer, sizeof(char) * bufferSize);
      }
    if(_read(tblPtr, &buffer[c], 1) == 0) { // file end
      if(errorFlag == 1) printf("\n");
      return;
      }
    c++;
    }
  while(buffer[c - 1] != 0x0d);  // break at end of line
  _read(tblPtr, &buffer[c - 1], 1); // remove 0x0a
  buffer[c - 1] = 0;
  if(c == 1) goto newLine;

  if(hex(buffer[0]) > 0 || buffer[0] == '0'){ // starts with hex digit, normal entry
    if((hex(buffer[2]) > 0 || buffer[2] == '0') && buffer[1] != '='){
      if(hex(buffer[3]) > 0 || buffer[3] == '0'){ // XXXX -> XX XX
	convertFrom2[entry] = readXX(&buffer[2], 2);
	convertFrom[entry] = readXX(buffer, 2);
	}
      else{  // XXX -> 0X XX
	convertFrom2[entry] = readXX(&buffer[1], 2);
	convertFrom[entry] = hex(buffer[0]);
	}
      status[entry] += 128;
      }
    else
      convertFrom[entry] = readXX(buffer, 2);
    if(hex(buffer[1]) > 0 || buffer[1] == '0' || buffer[1] == '='){ // good
      c = 1;
      c += seekChar(&buffer[c], '=');
      if(buffer[c] == 0) // no convert-to entry
        goto fail;
      c++; // indexing first char of convert-to
      if(buffer[c] == 0) goto fail;
      d = 0;
      while(buffer[c] != 0){
	convertTo[entry][d] = buffer[c];
	c++;
	d++;
	convertTo[entry] = (unsigned char*) realloc(convertTo[entry], sizeof(char) *
	    (d + 1));
	}
      convertTo[entry][d] = 0;
      status[entry] += 1; // bit 0: trigger to look at controlChar
      goto succeed;
      }
    }

  if(buffer[0] == 'l' || buffer[0] == 's' || buffer[0] == 'm' || buffer[0] == 'L' ||
      buffer[0] == 'S' || buffer[0] == 'M'){ // line/sect/msg break
    c = 0;
    c += seekChar(buffer, ':');
    if(buffer[c] == 0) goto fail;
    c++;
    c += seekPastSpace(&buffer[c]);
    if(buffer[c] == 0) goto fail;
    if(hex(buffer[c]) == 0 && buffer[c] != '0') goto fail;
    switch(buffer[0]){
      case 'l':  case 'L':
	if(testBit(breakStatus, 0) == 1) goto fail; // already a line break
	newLine = readXX(&buffer[c], 2);
	breakStatus += 1;
	if(buffer[c + 1] != 0)
	  if(buffer[c + 2] != 0){
	    newLine2 = readXX(&buffer[c + 2], 2);
	    breakStatus += 8;
	    }
	break;
      case 's': case 'S':
	if(testBit(breakStatus, 1) == 1) goto fail;
	newSection = readXX(&buffer[c], 2);
	breakStatus += 2;
	if(buffer[c + 1] != 0)
	  if(buffer[c + 2] != 0){
	    newSection2 = readXX(&buffer[c + 2], 2);
	    breakStatus += 16;
	    }
	break;
      case 'm': case 'M':
	if(testBit(breakStatus, 2) == 1) goto fail;
	newMessage = readXX(&buffer[c], 2);
	breakStatus += 4;
	if(buffer[c + 1] != 0)
	  if(buffer[c + 2] != 0){
	    newMessage2 = readXX(&buffer[c + 2], 2);
	    breakStatus += 32;
	    }
	break;
      }
    goto newLine;
    }

  if(buffer[0] == 'p' || buffer[1] == 'P'){ // Program-control flag label
    c = 1;
    c += seekChar(&buffer[c], ':');
    if(buffer[c] == 0) goto fail;
    c++;
    c += seekPastSpace(&buffer[c]);
    if(buffer[c] == 0) goto fail;
    if(hex(buffer[c]) == 0 && buffer[c] != '0') goto fail;
    convertFrom[entry] = readXX(&buffer[c], 2);
    c += seekChar(&buffer[c], '=');
    if(buffer[c] == 0) goto fail;
    c++;
    if(buffer[c] == 0) goto fail;
    d = 0;
    while(buffer[c] != 0){
      convertTo[entry][d] = buffer[c];
      c++;
      d++;
      convertTo[entry] = (unsigned char*) realloc(convertTo[entry], sizeof(char) *
          (d + 1));
      }
    convertTo[entry][d] = 0;
    status[entry] += 2; // bit 1: trigger to look at controlChar
    goto succeed;
    }

  if(buffer[0] == '?'){ // Instructions to SE
    switch(buffer[1]){
      case '0': case '1': case '2': // treatment of unconvertable bytes
	unconvertableMode = buffer[1] - '0';
	break;
      case 'a': case 'A': // append to text file instead of truncating
	appendFlag = 1;
	break;
      case 'b': case 'B': // conversion of break characters
	c = 2;
	c += seekChar(&buffer[c], ':');
	if(buffer[c] == 0) goto fail;
	c++;
        c += seekPastSpace(&buffer[c]);
	switch(buffer[c]){
	  case '0': case '1': case '2':
	    breakConversion = buffer[c] - '0';
            break;
	  default: goto fail;
	  }
	break;
      case 'l': case 's': case 'm': case 'L': case 'S': case 'M':
	c = 2;  // line/sect/msg length limit
	c += seekChar(&buffer[c], ':');
	if(buffer[c] == 0) goto fail;
	c++;
	c += seekPastSpace(&buffer[c]);
	switch(buffer[1]){
	  case 'l': case 'L':
	    lineLength = readDD(&buffer[c], 4);
	    if(lineLength == 0)
	      goto fail;
	    break;
	  case 's': case 'S':
	    sectionLength = readDD(&buffer[c], 4);
	    if(sectionLength == 0)
	      goto fail;
	    break;
	  case 'm': case 'M':
	    messageLength = readDD(&buffer[c], 4);
	    if(messageLength == 0)
	      goto fail;
            break;
	  }
	break;
      case 'p': case 'P': // pointer table define
	c = seekChar(buffer, ':');
	if(buffer[c] == 0) goto fail;
	c++;
	c += seekPastSpace(&buffer[c]);
	ptrTblOffset = readXX(&buffer[c], 8);
	if(ptrTblOffset == 0 && buffer[c] != '0') goto fail;
	break;
      default: goto fail;
      }
    goto newLine; // not a conversion line -- just affects program exec.
    }

  if(buffer[0] == '*' || buffer[0] == '/'){ // Thingy support
    if(hex(buffer[1]) == 0 && buffer[1] != '0') goto fail;
    switch(buffer[0]){
      case '*': // line break
	if(testBit(breakStatus, 0) == 1) goto fail;
	newLine = readXX(&buffer[1], 2);
        breakStatus += 1;
	break;
      case '/': // message break
	if(testBit(breakStatus, 2) == 1) goto fail;
	newMessage = readXX(&buffer[1], 2);
        breakStatus += 4;
	break;
      }
    goto newLine;
    }

  fail:
  if(errorFlag == 0) printf("\n"); // nice spacing =)
  errorFlag = 1;
  printf("Couldn't interpret \"%s\".\n", buffer);
  goto newLine;

  succeed:
  entry ++;
  convertFrom = (unsigned char*) realloc(convertFrom, sizeof(unsigned char) *
      (entry + 1));
  convertFrom2 = (unsigned char*) realloc(convertFrom2, sizeof(unsigned char) *
      (entry + 1));
  status = (unsigned char*) realloc(status, sizeof(unsigned char) *
      (entry + 1));
  status[entry] = 0;
  convertTo = (unsigned char**) realloc(convertTo, sizeof(char*) * (entry + 1));
  convertTo[entry] = (unsigned char*) malloc(sizeof(char));
  goto newLine;
  }